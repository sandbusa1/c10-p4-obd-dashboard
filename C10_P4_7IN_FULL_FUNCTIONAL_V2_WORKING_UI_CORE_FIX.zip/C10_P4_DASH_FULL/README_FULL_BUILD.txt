C10 P4 DASH FULL BUILD
Target: Waveshare ESP32-P4-WIFI6-Touch-LCD-7B, ESP-IDF 5.5.x

This is the full source project, not a demo/preview package.

Included:
- Existing OBDLink EX USB-host backend and automatic protocol logic
- GM P01/0411 + 4L60E commanded gear support
- Driver page: MPH, RPM, water temp, volts, 1-4 commanded gear
- Engine page with live PCM values and oil-pressure placeholder/input
- Diagnostics page with read/clear DTC support
- Settings page: brightness, needle smoothing, startup sweep
- 3-second 1968 C10 splash screen embedded in firmware
- Needle smoothing and startup sweep
- Coolant/voltage warning color behavior
- Touch navigation across 4 pages
- Existing SD logger and OEM diagnostic source retained in project for later reuse

Oil pressure:
The Engine page must show unavailable until a verified source is added.
The existing obd_auto_set_oil_pressure(psi, valid) API is retained for that future input.

IMPORTANT:
This package was assembled and statically checked in ChatGPT's build environment.
A complete ESP-IDF/Waveshare hardware compile and flash cannot be performed here because
the ESP-IDF toolchain/hardware are not available in this runtime. If ESP-IDF reports a
compile error on your PC, use the exact error against this ZIP as the correction base.
