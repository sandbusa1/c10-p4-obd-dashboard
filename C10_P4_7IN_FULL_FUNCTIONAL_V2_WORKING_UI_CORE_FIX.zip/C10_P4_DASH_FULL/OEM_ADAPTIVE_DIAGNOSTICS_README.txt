OBD2 V3K ADAPTIVE OEM DIAGNOSTICS
=================================

CURRENT HARDWARE PATH
- OBDLink EX over USB/FTDI is fully retained and auto-connects as before.
- Standard OBD-II remains the normal live-data engine.
- EX capabilities exposed to the UI: Standard OBD-II + Ford MS-CAN + USB.

MX+ IMPORTANT LIMITATION
- OBDLink MX+ is Bluetooth, not USB.
- This build models MX+ capability differences (including SW-CAN) so the OEM engine/UI can adapt,
  but the current firmware does NOT yet contain an MX+ Bluetooth transport through the board's ESP32-C6.
- Therefore an MX+ cannot physically connect to this build yet. EX continues to work normally.

PAGE 5 - OEM DIAGNOSTICS (READ ONLY)
Profiles:
- Ford
- GM
- Chrysler/Jeep
- BMW
- Land Rover / Range Rover

The READ-ONLY SCAN intentionally does not send coding, programming, actuator, key/immobilizer,
flash, configuration-write, or security-access commands.

Current scan capabilities:
- Detect/log OBDLink identity (ATI/STI)
- Show adapter capability flags
- Ford: safely probe OBDLink MS-CAN preset support (STP53)
- GM: clearly reports SW-CAN unavailable on EX and reserved for MX+ transport
- Chrysler/Jeep, BMW, Land Rover: read-only framework/status with standard VIN probe when available
- Standard VIN response probe (Mode 09 PID 02)
- Restore automatic OBD protocol selection (ATSP0) after a profile probe
- Log OEM profile changes and scan results to SD card

This is an OEM diagnostics framework, not a claim of universal manufacturer-module coverage.
Vehicle-specific module addresses/DIDs/PIDs must be added by platform/year for deeper enhanced data.
