MAIN BUILD - PAGES 1/2 VEHICLE CAPABILITY AUTO-DISCOVERY

- Reads Mode 01 supported-PID bitmaps 0100 / 0120 / 0140 after connection.
- Polls only PIDs the connected vehicle advertises.
- Page 1 keeps high-priority MPH/RPM and fills its 8 side cards with supported values.
- Page 2 fills its 16 cells with additional supported values rather than fixed unsupported zeros.
- Unsupported slots show N/A / NO MORE PIDS.
- RPM remains the high-priority polling lane for fast tach response.
- Added standard live data support for fuel pressure, MIL distance, EGR command/error, evap purge, warmups, distance since clear, barometric pressure, control-module voltage, relative throttle, ambient temperature, commanded throttle, ethanol percentage, plus existing values.
- Existing EX and OBDX Pro VX transports, Ford/GM diagnostics, DTC read/reset, touch mapping, SD logging, OEM page, and fast-start behavior remain.

Validation performed here: source brace/parenthesis balance, font references, fixed-status overflow check, ZIP integrity. Full idf.py compile still requires ESP-IDF 5.5.5 on the target Windows environment.
