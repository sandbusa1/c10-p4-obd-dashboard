DRIVER UI MASTER - 2026-09-30

Approved visual master: DRIVER_UI_MASTER.png

Dynamic Driver screen implemented in main/dashboard_ui.c for the existing 1024x600 Waveshare ESP32-P4-WIFI6-Touch-LCD-7B project.
Live items:
- MPH numeric + speed needle
- RPM numeric + tach needle
- Coolant temperature
- Battery voltage
- GM 0411/P01 PRND range via 221951
- 4L60E commanded gear 1-4 via 22199A

The master PNG is reference artwork only. Runtime UI is LVGL and does not fake sensor values.
Other project pages and OBDLink EX backend are retained.
