VX CDC FIX - MAIN BUILD

Detected hardware from real monitor log:
  OBDX Pro VX USB VID=0483 PID=5740

Runtime transport auto-selection:
  0403:6015 -> OBDLink EX -> existing FTDI bulk transport
  0483:5740 -> OBDX Pro VX -> Espressif USB CDC-ACM host transport

VX CDC configuration:
  115200 baud, 8 data bits, no parity, 1 stop bit
  RX callbacks feed the existing OBD/ELM parser
  TX uses cdc_acm_host_data_tx_blocking()

The normal dashboard, touch-Y fix, OEM page, SD logging and OBD state machine are unchanged.
The separate FLASHING branch is not included.
