SD CARD LOGGING
===============

This build uses the Waveshare 7B BSP's official microSD mount function.
Insert a FAT/FAT32 microSD card before boot.

Log file:
  /sdcard/obd2.log

Rotated previous file:
  /sdcard/obd2.old.log

The current log rotates at approximately 1 MiB. Rotation is checked every 50 writes.
If no SD card is present or mounting fails, the dashboard and OBD reader continue normally.

Logged events:
- boot/startup
- OBD stack startup
- OBD connection/state changes
- selected vehicle protocol
- navigation page changes
- READ CODES / CLEAR CODES actions and DTC refreshes
- live PID snapshot every 5 seconds while the OBD loop is running

Periodic PID snapshots include RPM, MPH, throttle, engine load, MAP, MAF,
coolant, intake temperature, AFR, timing, fuel level, battery voltage,
fuel trims, MIL/DTC status, and OBD success/no-data/error counters.
