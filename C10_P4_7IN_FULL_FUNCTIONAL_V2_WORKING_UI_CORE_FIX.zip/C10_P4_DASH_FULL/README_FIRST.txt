ESP32-P4 WAVESHARE 7B OBD2 DASH - V3K V32 REBUILT + STRICT AUDIT

Target hardware
- Waveshare ESP32-P4-WIFI6-Touch-LCD-7B, 1024x600
- Confirmed ESP32-P4 silicon rev 1.3
- OBDLink EX in USB-A host port, FTDI VID:PID 0403:6015, 115200 baud
- ESP-IDF 5.5.x; intended/test target is v5.5.5

Included
- Correct main/idf_component.yml for automatic managed dependency download
- Waveshare 7B BSP 3.0.1
- LVGL 9.5.0
- Direct ESP-IDF USB Host FTDI transport
- Non-blocking USB event callback/state-machine configuration
- Automatic protocol search: VPW first, then CAN/PWM/ISO/KWP
- Fast RPM polling and 25 Hz change-only UI
- Page 1: speed, RPM, coolant, volts, fuel, forward gear, oil-pressure-ready input, 5.3 LS
- Five live arcs: RPM / coolant / volts / fuel / oil pressure
- Page 2: AFR / IAT / TPS / MAP / LOAD / MAF / timing / runtime
- Page 3: protocol/state / MIL / DTC count/codes / refresh / clear
- GM 22199A forward-gear decoding (1-4 only when moving)
- 12 MB factory partition and 32 MB total flash map

FIRST BUILD - use a FRESH extracted folder
1. Open ESP-IDF 5.5.5 terminal in this project directory.
2. Run:
     idf.py set-target esp32p4
     idf.py build
3. Then flash using the current COM port, for example:
     idf.py -p COM19 -b 460800 flash monitor

IMPORTANT
Do not copy an old sdkconfig or build folder into this project. The included defaults explicitly
select your rev1.3 silicon profile and 200 MHz PSRAM. See PREBUILD_AUDIT.txt for the strict audit.
