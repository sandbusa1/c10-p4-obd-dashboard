MAIN BUILD - HS/MS/SW CAN ADAPTER-AWARE DIAGNOSTICS

This remains the non-flashing dashboard branch.

Changes:
- Adds an explicit HS-CAN capability flag and shows it on OEM Diagnostics page.
- Adapter capability profiles:
  * OBDX Pro VX: HS-CAN + J1850-VPW; Ford MS-CAN and GM SW-CAN are skipped.
  * OBDLink EX: HS-CAN + Ford MS-CAN + legislated legacy OBD protocols.
  * OBDX Pro FT identity hook: HS-CAN + Ford MS-CAN.
  * OBDX Pro GT identity hook: HS-CAN + GM SW-CAN/GMLAN + J1850-VPW.
- OEM scan always probes HS-CAN first where supported.
- Ford scan only switches to MS-CAN when the adapter advertises MS-CAN.
- GM scan reports SW-CAN as skipped on VX instead of wasting time trying an impossible bus.
- Existing startup protocol search, MIL/DTC scan, Ford HS-CAN DTC retry, GM headers,
  EX/VX USB auto-select, and global X/Y touch mapping remain intact.

Important:
- Standard OBD/MIL/DTC traffic is normally on the legislated powertrain network.
- Ford MS-CAN and GM SW-CAN enhanced module discovery requires OEM-specific addresses/services.
- The current physical USB transport is proven for OBDLink EX and OBDX Pro VX.
  FT/GT model capability classification is ready if a compatible serial transport is connected,
  but their USB descriptors have not been hardware-verified in this project.
