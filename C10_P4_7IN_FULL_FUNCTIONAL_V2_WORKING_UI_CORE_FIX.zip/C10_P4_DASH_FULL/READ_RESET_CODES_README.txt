MAIN BUILD - READ + RESET CODES

Page 3 now provides:
- READ CODES: stored (Mode 03), pending (Mode 07), permanent (Mode 0A)
- RESET CODES: standard OBD-II Mode 04
- RESET requires a second press within 5 seconds
- RESET is blocked when engine RPM indicates the engine is running
- Use ignition ON, engine OFF for reset
- Ford profile: if Mode 04 is not acknowledged, retries HS-CAN 11-bit/500 with functional header 7DF
- After a successful reset command, DTCs are re-read automatically for verification

Note: Standard Mode 04 clears emissions-related DTCs/MIL and may reset readiness/freeze-frame information. OEM module DTC clearing (ABS/SRS/body, etc.) requires module-specific enhanced diagnostics.
