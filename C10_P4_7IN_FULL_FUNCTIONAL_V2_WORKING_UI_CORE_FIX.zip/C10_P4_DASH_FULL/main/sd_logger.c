#include "sd_logger.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "bsp/esp-bsp.h"

static const char *TAG = "SD_LOG";
static const char *LOG_PATH = "/sdcard/obd2.log";
static const char *OLD_PATH = "/sdcard/obd2.old.log";
static SemaphoreHandle_t s_mutex;
static bool s_ready;
static bool s_enabled = true;
static unsigned s_write_count;

#define LOG_ROTATE_BYTES (1024 * 1024)

static void rotate_if_needed_locked(void)
{
    if ((s_write_count++ % 50U) != 0U) return;
    struct stat st;
    if (stat(LOG_PATH, &st) != 0 || st.st_size < LOG_ROTATE_BYTES) return;
    remove(OLD_PATH);
    if (rename(LOG_PATH, OLD_PATH) == 0) {
        ESP_LOGI(TAG, "Rotated log at %ld bytes", (long)st.st_size);
    }
}

static void write_line_locked(const char *tag, const char *msg)
{
    rotate_if_needed_locked();
    FILE *f = fopen(LOG_PATH, "a");
    if (!f) {
        ESP_LOGE(TAG, "Open %s failed", LOG_PATH);
        return;
    }
    long long ms = esp_timer_get_time() / 1000LL;
    fprintf(f, "%lld ms | %-12s | %s\n", ms, tag ? tag : "LOG", msg ? msg : "");
    fflush(f);
    fclose(f);
}

esp_err_t sd_logger_start(void)
{
    if (s_ready) return ESP_OK;
    if (!s_mutex) {
        s_mutex = xSemaphoreCreateMutex();
        if (!s_mutex) return ESP_ERR_NO_MEM;
    }

    esp_err_t err = bsp_sdcard_mount();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "SD card not mounted; file logging disabled: %s", esp_err_to_name(err));
        return err;
    }

    s_ready = true;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    write_line_locked("BOOT", "SD logging started; build=V3K_ALLDATA_DTC_REPAIRED");
    xSemaphoreGive(s_mutex);
    ESP_LOGI(TAG, "Logging to %s", LOG_PATH);
    return ESP_OK;
}

bool sd_logger_ready(void)
{
    return s_ready;
}

void sd_logger_event(const char *tag, const char *fmt, ...)
{
    if (!s_ready || !s_enabled || !s_mutex || !fmt) return;
    char msg[384];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    write_line_locked(tag, msg);
    xSemaphoreGive(s_mutex);
}

void sd_logger_snapshot(const obd_data_t *d)
{
    if (!d) return;
    sd_logger_event("PID",
        "state=%s protocol=%s adapter=%s caps=0x%lx oem=%s rpm=%d mph=%.1f tps=%.1f load=%.1f map=%.1f maf=%.2f ectF=%.1f iatF=%.1f afr=%.2f timing=%.1f fuel=%.1f volts=%.2f stft1=%.1f ltft1=%.1f stft2=%.1f ltft2=%.1f mil=%d dtc=%d good=%lu nodata=%lu errors=%lu",
        d->state, d->protocol, d->adapter_name, (unsigned long)d->adapter_caps, d->oem_profile,
        d->rpm, d->mph, d->tps, d->load, d->map_kpa, d->maf_gps,
        d->ect_f, d->iat_f, d->afr, d->timing_deg, d->fuel_pct, d->volts,
        d->stft1, d->ltft1, d->stft2, d->ltft2, d->mil_on ? 1 : 0, d->dtc_count,
        (unsigned long)d->good, (unsigned long)d->nodata, (unsigned long)d->errors);
    sd_logger_event("PIDX",
        "absload=%.1f pedalD=%.1f pedalE=%.1f relpedal=%.1f oilF=%.1f inj=%.1f fuelrate=%.2f rail=%.0f railabs=%.0f cat11F=%.0f cat21F=%.0f actualAFR=%.2f tqdem=%.0f tqact=%.0f tqref=%lu runtime=%lu mildist=%lu milmin=%lu clearmin=%lu baro=%.0f moduleV=%.2f",
        d->abs_load_pct, d->pedal_d_pct, d->pedal_e_pct, d->rel_accel_pct, d->oil_temp_f,
        d->injection_timing_deg, d->fuel_rate_lph, d->fuel_rail_kpa, d->fuel_rail_abs_kpa,
        d->catalyst_b1s1_f, d->catalyst_b2s1_f, d->actual_afr, d->demanded_torque_pct,
        d->actual_torque_pct, (unsigned long)d->reference_torque_nm, (unsigned long)d->runtime_s,
        (unsigned long)d->distance_mil_km, (unsigned long)d->mil_time_min, (unsigned long)d->clear_time_min,
        d->baro_kpa, d->control_module_v);
}


void sd_logger_set_enabled(bool enabled)
{
    if (!s_ready || !s_mutex) return;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    if (enabled && !s_enabled) {
        s_enabled = true;
        write_line_locked("LOG", "logging enabled from UI");
    } else if (!enabled && s_enabled) {
        write_line_locked("LOG", "logging disabled from UI");
        s_enabled = false;
    }
    xSemaphoreGive(s_mutex);
}

bool sd_logger_enabled(void)
{
    return s_ready && s_enabled;
}

esp_err_t sd_logger_clear(void)
{
    if (!s_ready || !s_mutex) return ESP_ERR_INVALID_STATE;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    FILE *f = fopen(LOG_PATH, "w");
    if (!f) {
        xSemaphoreGive(s_mutex);
        return ESP_FAIL;
    }
    fclose(f);
    s_write_count = 0;
    if (s_enabled) write_line_locked("LOG", "log cleared from UI");
    xSemaphoreGive(s_mutex);
    return ESP_OK;
}

esp_err_t sd_logger_rotate_now(void)
{
    if (!s_ready || !s_mutex) return ESP_ERR_INVALID_STATE;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    remove(OLD_PATH);
    int rc = rename(LOG_PATH, OLD_PATH);
    if (rc == 0 && s_enabled) write_line_locked("LOG", "new log started after manual rotate");
    xSemaphoreGive(s_mutex);
    return rc == 0 ? ESP_OK : ESP_FAIL;
}

size_t sd_logger_read_tail(char *out, size_t out_size)
{
    if (!out || out_size < 2) return 0;
    out[0] = '\0';
    if (!s_ready || !s_mutex) return 0;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    FILE *f = fopen(LOG_PATH, "rb");
    if (!f) {
        xSemaphoreGive(s_mutex);
        return 0;
    }
    if (fseek(f, 0, SEEK_END) != 0) {
        fclose(f); xSemaphoreGive(s_mutex); return 0;
    }
    long end = ftell(f);
    long want = (long)out_size - 1;
    long start = end > want ? end - want : 0;
    if (fseek(f, start, SEEK_SET) != 0) {
        fclose(f); xSemaphoreGive(s_mutex); return 0;
    }
    size_t n = fread(out, 1, out_size - 1, f);
    out[n] = '\0';
    fclose(f);
    xSemaphoreGive(s_mutex);

    /* If we started in the middle of a line, drop that partial first line. */
    if (start > 0) {
        char *nl = strchr(out, '\n');
        if (nl) {
            size_t remain = n - (size_t)(nl + 1 - out);
            memmove(out, nl + 1, remain);
            out[remain] = '\0';
            n = remain;
        }
    }
    return n;
}
