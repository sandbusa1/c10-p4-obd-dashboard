#include "dashboard_ui.h"
#include "obd_auto.h"
#include "sd_logger.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "lvgl.h"
#include "bsp/esp-bsp.h"

extern const uint8_t splash_rgb565_start[] asm("_binary_splash_rgb565_start");
extern const uint8_t splash_rgb565_end[] asm("_binary_splash_rgb565_end");
static lv_obj_t *splash_screen;

static const char *TAG = "DASH7B_V3";

/* ---- palette ---- */
#define COL_BG          0x05080D
#define COL_CARD_BG     0x0B1420
#define COL_CARD_BORDER 0x1C2A3A
#define COL_LABEL       0x7E93AC
#define COL_VALUE       0xE9EEF5
#define COL_MPH         0xFFC400
#define COL_RPM         0x22D3EE
#define COL_ICON        0x8AA0BE
#define COL_SEG_DIM     0x14181F
#define COL_GREEN       0x2ECC40
#define COL_YELLOW      0xFFD400
#define COL_ORANGE      0xFF8C1A
#define COL_RED         0xFF3B30
#define COL_MIL_ON      0xFF3B30
#define COL_MIL_OFF     0x7E93AC

#define RPM_REDLINE     6500
#define N_SEGS          11

typedef enum {
    ICON_MAP, ICON_THROTTLE, ICON_LOAD, ICON_MAF,
    ICON_COOLANT, ICON_BATTERY, ICON_FUEL, ICON_TIMING
} icon_kind_t;

static lv_obj_t *pages[5];
static int page_now;

/* page 1 widgets */
static lv_obj_t *seg[N_SEGS];
static lv_obj_t *l1_mph, *l1_rpm, *l1_status;
static lv_obj_t *mph_digit[3];
static lv_obj_t *mph_seg[3][7];
static lv_obj_t *l1_map, *l1_thr, *l1_load, *l1_maf;
static lv_obj_t *l1_cool, *l1_batt, *l1_fuel, *l1_time;
static lv_obj_t *p1_title[8], *p1_value[8];
/* Driver master screen live widgets. */
static lv_obj_t *drv_mph, *drv_rpm, *drv_cool, *drv_volts;
static lv_obj_t *drv_gear;
static lv_obj_t *drv_gear_box[4];
static int64_t s_ui_boot_us;
static lv_obj_t *drv_cool_arc, *drv_volt_arc;
static lv_obj_t *drv_speed_needle, *drv_rpm_needle;
static lv_point_precise_t drv_speed_pts[2], drv_rpm_pts[2];

/* page 2 widgets: titles/values are capability-driven from the vehicle PID map. */
static lv_obj_t *l2_rpm, *l2_mph, *l2_load, *l2_map;
static lv_obj_t *l2_maf, *l2_tps, *l2_iat, *l2_ect;
static lv_obj_t *l2_afr, *l2_timing, *l2_stft1, *l2_ltft1;
static lv_obj_t *l2_stft2, *l2_ltft2, *l2_fuel, *l2_volts;
static lv_obj_t *p2_title[16], *p2_value[16];
static lv_obj_t *l2_page_title;

/* page 3 widgets (diagnostic codes) */
static lv_obj_t *l3_status, *l3_dtccount, *l3_dtcs;
static lv_obj_t *l3_clear_label;
static int64_t s_clear_confirm_deadline_us;

/* page 4 widgets (SD log viewer + controls) */
static lv_obj_t *l4_status, *l4_log, *l4_toggle_label;
static lv_obj_t *set_brightness_label, *set_smoothing_label, *set_sweep_label;
static int s_brightness_pct = 82;
static bool s_smoothing = true;
static bool s_startup_sweep = true;

/* page 5 widgets (adaptive OEM diagnostics) */
static lv_obj_t *l5_adapter, *l5_caps, *l5_profile, *l5_status, *l5_result;

static void set_speed_digits(float mph);

static void nav_cb(lv_event_t *e)
{
    int p = (int)(intptr_t)lv_event_get_user_data(e);
    if (p < 0 || p > 4) return;
    ESP_LOGI(TAG, "NAV: page %d -> %d", page_now + 1, p + 1);
    sd_logger_event("NAV", "page %d -> %d", page_now + 1, p + 1);
    lv_screen_load(pages[p]);
    page_now = p;
}

static void make_icon(lv_obj_t *parent, icon_kind_t kind, int x, int y)
{
    lv_color_t c = lv_color_hex(COL_ICON);
    switch (kind) {
    case ICON_MAP: {
        lv_obj_t *ring = lv_obj_create(parent);
        lv_obj_remove_style_all(ring);
        lv_obj_set_pos(ring, x, y);
        lv_obj_set_size(ring, 30, 30);
        lv_obj_set_style_bg_opa(ring, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(ring, 3, 0);
        lv_obj_set_style_border_color(ring, c, 0);
        lv_obj_set_style_radius(ring, 100, 0);
        lv_obj_t *needle = lv_line_create(parent);
        static lv_point_precise_t p_map[2];
        p_map[0].x = x + 15; p_map[0].y = y + 15;
        p_map[1].x = x + 15; p_map[1].y = y + 2;
        lv_line_set_points(needle, p_map, 2);
        lv_obj_set_style_line_width(needle, 3, 0);
        lv_obj_set_style_line_color(needle, c, 0);
        lv_obj_set_style_line_rounded(needle, true, 0);
        break;
    }
    case ICON_THROTTLE: {
        lv_obj_t *ring = lv_obj_create(parent);
        lv_obj_remove_style_all(ring);
        lv_obj_set_pos(ring, x, y);
        lv_obj_set_size(ring, 30, 30);
        lv_obj_set_style_bg_opa(ring, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(ring, 3, 0);
        lv_obj_set_style_border_color(ring, c, 0);
        lv_obj_set_style_radius(ring, 100, 0);
        lv_obj_t *plate = lv_line_create(parent);
        static lv_point_precise_t p_thr[2];
        p_thr[0].x = x + 5;  p_thr[0].y = y + 9;
        p_thr[1].x = x + 25; p_thr[1].y = y + 21;
        lv_line_set_points(plate, p_thr, 2);
        lv_obj_set_style_line_width(plate, 3, 0);
        lv_obj_set_style_line_color(plate, c, 0);
        lv_obj_set_style_line_rounded(plate, true, 0);
        break;
    }
    case ICON_LOAD: {
        lv_obj_t *pulse = lv_line_create(parent);
        static lv_point_precise_t p_pulse[6];
        p_pulse[0].x = x;      p_pulse[0].y = y + 18;
        p_pulse[1].x = x + 7;  p_pulse[1].y = y + 18;
        p_pulse[2].x = x + 11; p_pulse[2].y = y + 2;
        p_pulse[3].x = x + 16; p_pulse[3].y = y + 32;
        p_pulse[4].x = x + 20; p_pulse[4].y = y + 18;
        p_pulse[5].x = x + 30; p_pulse[5].y = y + 18;
        lv_line_set_points(pulse, p_pulse, 6);
        lv_obj_set_style_line_width(pulse, 3, 0);
        lv_obj_set_style_line_color(pulse, c, 0);
        lv_obj_set_style_line_rounded(pulse, true, 0);
        break;
    }
    case ICON_MAF: {
        lv_obj_t *w1 = lv_line_create(parent);
        static lv_point_precise_t p_w1[5];
        p_w1[0].x = x;      p_w1[0].y = y + 8;
        p_w1[1].x = x + 7;  p_w1[1].y = y + 2;
        p_w1[2].x = x + 15; p_w1[2].y = y + 8;
        p_w1[3].x = x + 22; p_w1[3].y = y + 14;
        p_w1[4].x = x + 30; p_w1[4].y = y + 8;
        lv_line_set_points(w1, p_w1, 5);
        lv_obj_set_style_line_width(w1, 3, 0);
        lv_obj_set_style_line_color(w1, c, 0);
        lv_obj_set_style_line_rounded(w1, true, 0);
        lv_obj_t *w2 = lv_line_create(parent);
        static lv_point_precise_t p_w2[5];
        p_w2[0].x = x;      p_w2[0].y = y + 24;
        p_w2[1].x = x + 7;  p_w2[1].y = y + 18;
        p_w2[2].x = x + 15; p_w2[2].y = y + 24;
        p_w2[3].x = x + 22; p_w2[3].y = y + 30;
        p_w2[4].x = x + 30; p_w2[4].y = y + 24;
        lv_line_set_points(w2, p_w2, 5);
        lv_obj_set_style_line_width(w2, 3, 0);
        lv_obj_set_style_line_color(w2, c, 0);
        lv_obj_set_style_line_rounded(w2, true, 0);
        break;
    }
    case ICON_COOLANT: {
        lv_obj_t *stem = lv_obj_create(parent);
        lv_obj_remove_style_all(stem);
        lv_obj_set_pos(stem, x + 12, y);
        lv_obj_set_size(stem, 6, 20);
        lv_obj_set_style_bg_opa(stem, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(stem, 3, 0);
        lv_obj_set_style_border_color(stem, c, 0);
        lv_obj_set_style_radius(stem, 3, 0);
        lv_obj_t *bulb = lv_obj_create(parent);
        lv_obj_remove_style_all(bulb);
        lv_obj_set_pos(bulb, x + 8, y + 18);
        lv_obj_set_size(bulb, 14, 14);
        lv_obj_set_style_bg_color(bulb, c, 0);
        lv_obj_set_style_bg_opa(bulb, LV_OPA_COVER, 0);
        lv_obj_set_style_radius(bulb, 100, 0);
        break;
    }
    case ICON_BATTERY: {
        lv_obj_t *body = lv_obj_create(parent);
        lv_obj_remove_style_all(body);
        lv_obj_set_pos(body, x + 1, y + 8);
        lv_obj_set_size(body, 28, 18);
        lv_obj_set_style_bg_opa(body, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(body, 3, 0);
        lv_obj_set_style_border_color(body, c, 0);
        lv_obj_set_style_radius(body, 3, 0);
        lv_obj_t *nub = lv_obj_create(parent);
        lv_obj_remove_style_all(nub);
        lv_obj_set_pos(nub, x + 12, y + 2);
        lv_obj_set_size(nub, 6, 6);
        lv_obj_set_style_bg_color(nub, c, 0);
        lv_obj_set_style_bg_opa(nub, LV_OPA_COVER, 0);
        lv_obj_set_style_radius(nub, 1, 0);
        break;
    }
    case ICON_FUEL: {
        lv_obj_t *tank = lv_obj_create(parent);
        lv_obj_remove_style_all(tank);
        lv_obj_set_pos(tank, x + 2, y + 8);
        lv_obj_set_size(tank, 16, 22);
        lv_obj_set_style_bg_opa(tank, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(tank, 3, 0);
        lv_obj_set_style_border_color(tank, c, 0);
        lv_obj_set_style_radius(tank, 3, 0);
        lv_obj_t *hose = lv_line_create(parent);
        static lv_point_precise_t p_hose[2];
        p_hose[0].x = x + 18; p_hose[0].y = y + 12;
        p_hose[1].x = x + 27; p_hose[1].y = y + 2;
        lv_line_set_points(hose, p_hose, 2);
        lv_obj_set_style_line_width(hose, 3, 0);
        lv_obj_set_style_line_color(hose, c, 0);
        lv_obj_set_style_line_rounded(hose, true, 0);
        break;
    }
    case ICON_TIMING: {
        lv_obj_t *arc = lv_arc_create(parent);
        lv_obj_set_pos(arc, x, y);
        lv_obj_set_size(arc, 30, 30);
        lv_arc_set_rotation(arc, 135);
        lv_arc_set_bg_angles(arc, 0, 270);
        lv_arc_set_range(arc, 0, 100);
        lv_obj_remove_style(arc, NULL, LV_PART_KNOB);
        lv_obj_remove_style(arc, NULL, LV_PART_INDICATOR);
        lv_obj_set_style_arc_width(arc, 3, LV_PART_MAIN);
        lv_obj_set_style_arc_color(arc, c, LV_PART_MAIN);
        lv_obj_set_style_bg_opa(arc, LV_OPA_TRANSP, 0);
        lv_obj_t *needle = lv_line_create(parent);
        static lv_point_precise_t p_time[2];
        p_time[0].x = x + 15; p_time[0].y = y + 15;
        p_time[1].x = x + 22; p_time[1].y = y + 6;
        lv_line_set_points(needle, p_time, 2);
        lv_obj_set_style_line_width(needle, 3, 0);
        lv_obj_set_style_line_color(needle, c, 0);
        lv_obj_set_style_line_rounded(needle, true, 0);
        break;
    }
    }
}

static lv_obj_t *card(lv_obj_t *parent, int x, int y, int w, int h,
                       icon_kind_t icon, bool has_icon, const char *title,
                       lv_obj_t **title_out, lv_obj_t **val_out)
{
    lv_obj_t *c = lv_obj_create(parent);
    lv_obj_remove_style_all(c);
    lv_obj_set_pos(c, x, y);
    lv_obj_set_size(c, w, h);
    lv_obj_set_style_bg_color(c, lv_color_hex(COL_CARD_BG), 0);
    lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(c, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_border_width(c, 1, 0);
    lv_obj_set_style_radius(c, 16, 0);

    int title_x = 20;
    if (has_icon) {
        make_icon(c, icon, 14, 16);
        title_x = 58;
    }
    lv_obj_t *lab = lv_label_create(c);
    lv_label_set_text(lab, title);
    lv_obj_set_pos(lab, title_x, 16);
    lv_obj_set_style_text_font(lab, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(lab, lv_color_hex(COL_LABEL), 0);
    if (title_out) *title_out = lab;

    lv_obj_t *val = lv_label_create(c);
    lv_label_set_text(val, "--");
    lv_obj_set_pos(val, 20, h - 42);
    lv_obj_set_style_text_font(val, &lv_font_montserrat_32, 0);
    lv_obj_set_style_text_color(val, lv_color_hex(COL_VALUE), 0);
    if (val_out) *val_out = val;
    return c;
}

/* large touch nav row shared by all five pages.
 * GT911 can report a little finger movement between press/release, so page
 * navigation is handled on PRESSED rather than CLICKED.  The touch targets
 * are intentionally large while the visible arrows remain compact. */
static void nav_row(lv_obj_t *p, int prev_page, int next_page, int page_no)
{
    lv_obj_t *bar = lv_obj_create(p);
    lv_obj_remove_style_all(bar);
    lv_obj_set_pos(bar, 24, 548);
    lv_obj_set_size(bar, 976, 48);
    lv_obj_clear_flag(bar, LV_OBJ_FLAG_SCROLLABLE);

    /* Visible button rectangle == touch hitbox: 180 x 48. */
    lv_obj_t *left = lv_button_create(bar);
    lv_obj_set_pos(left, 0, 0);
    lv_obj_set_size(left, 180, 48);
    lv_obj_set_style_bg_color(left, lv_color_hex(COL_CARD_BG), 0);
    lv_obj_set_style_bg_opa(left, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(left, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_border_width(left, 1, 0);
    lv_obj_set_style_radius(left, 10, 0);
    lv_obj_add_event_cb(left, nav_cb, LV_EVENT_PRESSED, (void *)(intptr_t)prev_page);
    lv_obj_t *ll = lv_label_create(left);
    lv_label_set_text(ll, "<");
    lv_obj_set_style_text_font(ll, &lv_font_montserrat_32, 0);
    lv_obj_set_style_text_color(ll, lv_color_hex(COL_LABEL), 0);
    lv_obj_clear_flag(ll, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_center(ll);

    lv_obj_t *right = lv_button_create(bar);
    lv_obj_set_pos(right, 796, 0);
    lv_obj_set_size(right, 180, 48);
    lv_obj_set_style_bg_color(right, lv_color_hex(COL_CARD_BG), 0);
    lv_obj_set_style_bg_opa(right, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(right, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_border_width(right, 1, 0);
    lv_obj_set_style_radius(right, 10, 0);
    lv_obj_add_event_cb(right, nav_cb, LV_EVENT_PRESSED, (void *)(intptr_t)next_page);
    lv_obj_t *rl = lv_label_create(right);
    lv_label_set_text(rl, ">");
    lv_obj_set_style_text_font(rl, &lv_font_montserrat_32, 0);
    lv_obj_set_style_text_color(rl, lv_color_hex(COL_LABEL), 0);
    lv_obj_clear_flag(rl, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_center(rl);

    char pc[8];
    snprintf(pc, sizeof(pc), "%d / 4", page_no);
    lv_obj_t *mid = lv_label_create(bar);
    lv_label_set_text(mid, pc);
    lv_obj_set_size(mid, 160, 40);
    lv_obj_set_pos(mid, 408, 4);
    lv_obj_set_style_text_align(mid, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_text_font(mid, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(mid, lv_color_hex(COL_VALUE), 0);
    lv_obj_clear_flag(mid, LV_OBJ_FLAG_CLICKABLE);

    lv_obj_move_foreground(bar);
}

static lv_obj_t *driver_label(lv_obj_t *p, const char *txt, int x, int y, int w, int h,
                              const lv_font_t *font, uint32_t color, lv_text_align_t align)
{
    lv_obj_t *o = lv_label_create(p);
    lv_label_set_text(o, txt);
    lv_obj_set_pos(o, x, y); lv_obj_set_size(o, w, h);
    lv_obj_set_style_text_font(o, font, 0);
    lv_obj_set_style_text_color(o, lv_color_hex(color), 0);
    lv_obj_set_style_text_align(o, align, 0);
    return o;
}

static void driver_arc(lv_obj_t *p, int x, int y, int size, int rot, int a0, int a1,
                       int width, uint32_t color)
{
    lv_obj_t *a = lv_arc_create(p);
    lv_obj_set_pos(a, x, y); lv_obj_set_size(a, size, size);
    lv_arc_set_rotation(a, rot); lv_arc_set_bg_angles(a, a0, a1);
    lv_obj_remove_style(a, NULL, LV_PART_KNOB);
    lv_obj_remove_style(a, NULL, LV_PART_INDICATOR);
    lv_obj_set_style_arc_width(a, width, LV_PART_MAIN);
    lv_obj_set_style_arc_color(a, lv_color_hex(color), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(a, LV_OPA_TRANSP, 0);
    lv_obj_clear_flag(a, LV_OBJ_FLAG_CLICKABLE);
}

static void driver_needle_set(lv_obj_t *line, lv_point_precise_t pts[2], int cx, int cy,
                              int radius, float value, float vmax)
{
    if (!line || vmax <= 0) return;
    if (value < 0) value = 0; if (value > vmax) value = vmax;
    /* 225 degrees at zero through 315 degrees at full scale: 270 degree sweep. */
    float deg = 225.0f + 270.0f * (value / vmax);
    float rad = deg * 0.01745329252f;
    pts[0].x = cx; pts[0].y = cy;
    pts[1].x = cx + (int)(radius * cosf(rad));
    pts[1].y = cy + (int)(radius * sinf(rad));
    lv_line_set_points(line, pts, 2);
}

static void driver_scale_labels(lv_obj_t *p, int cx, int cy, int r, int maxv, int step)
{
    char b[8]; int count = maxv / step;
    for (int i=0;i<=count;i++) {
        float deg=225.0f + 270.0f*((float)i/(float)count);
        float rad=deg*0.01745329252f;
        int x=cx+(int)(r*cosf(rad))-24, y=cy+(int)(r*sinf(rad))-14;
        snprintf(b,sizeof(b),"%d",i*step);
        driver_label(p,b,x,y,48,28,&lv_font_montserrat_24,COL_VALUE,LV_TEXT_ALIGN_CENTER);
    }
}

static void build_page1(void)
{
    lv_obj_t *p = pages[0] = lv_obj_create(NULL);
    lv_obj_remove_style_all(p);
    lv_obj_set_style_bg_color(p, lv_color_hex(0x02060B), 0);
    lv_obj_set_style_bg_opa(p, LV_OPA_COVER, 0);

    /* Factory-style Driver screen.  All decorative pieces are static LVGL objects;
       only needles, live values, lower active arcs, gear and status are updated. */

    /* Twin main bezels: dark outer barrel, metallic rings, blue illumination. */
    driver_arc(p, 38, 5, 445, 135, 0,270, 24,0x08131E);
    driver_arc(p,541, 5, 445, 135, 0,270, 24,0x08131E);
    driver_arc(p, 44,11, 433, 135, 0,270,  5,0xAAB7C2);
    driver_arc(p,547,11, 433, 135, 0,270,  5,0xAAB7C2);
    driver_arc(p, 50,17, 421, 135, 0,270,  8,0x0E8FE8);
    driver_arc(p,553,17, 421, 135, 0,218,  8,0x0E8FE8);
    driver_arc(p,553,17, 421, 135,218,270, 10,0xFF352F);
    driver_arc(p, 67,34, 387, 135, 0,270,  2,0x71889A);
    driver_arc(p,570,34, 387, 135, 0,270,  2,0x71889A);
    driver_arc(p, 88,55, 345, 135, 0,270,  1,0x124E79);
    driver_arc(p,591,55, 345, 135, 0,270,  1,0x124E79);

    /* Dense OEM-style major/minor ticks. */
    for (int g=0; g<2; g++) {
        int cx=g?764:260, cy=222;
        for (int i=0;i<=64;i++) {
            float deg=225.0f+270.0f*((float)i/64.0f), rad=deg*0.01745329252f;
            bool major=(i%8)==0, medium=(i%4)==0;
            int ro=199, ri=major?174:(medium?181:188);
            lv_obj_t *ln=lv_line_create(p);
            lv_point_precise_t *pts=lv_malloc(sizeof(lv_point_precise_t)*2);
            if(!pts) continue;
            pts[0].x=cx+(int)(ri*cosf(rad)); pts[0].y=cy+(int)(ri*sinf(rad));
            pts[1].x=cx+(int)(ro*cosf(rad)); pts[1].y=cy+(int)(ro*sinf(rad));
            lv_line_set_points(ln,pts,2);
            lv_obj_set_style_line_width(ln,major?4:(medium?2:1),0);
            uint32_t tc=(g && i>=50)?COL_RED:0xE8F2FA;
            lv_obj_set_style_line_color(ln,lv_color_hex(tc),0);
            lv_obj_clear_flag(ln,LV_OBJ_FLAG_CLICKABLE);
        }
    }
    driver_scale_labels(p,260,222,151,160,20);
    driver_scale_labels(p,764,222,151,7,1);

    /* Needle objects. */
    drv_speed_needle=lv_line_create(p); lv_line_set_points(drv_speed_needle,drv_speed_pts,2);
    lv_obj_set_style_line_width(drv_speed_needle,6,0); lv_obj_set_style_line_color(drv_speed_needle,lv_color_hex(0xFF3B30),0);
    lv_obj_set_style_line_rounded(drv_speed_needle,true,0);
    drv_rpm_needle=lv_line_create(p); lv_line_set_points(drv_rpm_needle,drv_rpm_pts,2);
    lv_obj_set_style_line_width(drv_rpm_needle,6,0); lv_obj_set_style_line_color(drv_rpm_needle,lv_color_hex(0xFF3B30),0);
    lv_obj_set_style_line_rounded(drv_rpm_needle,true,0);

    /* Dark needle hubs give the gauges depth. */
    for(int g=0;g<2;g++) {
        lv_obj_t *hub=lv_obj_create(p); lv_obj_remove_style_all(hub);
        lv_obj_set_size(hub,28,28); lv_obj_set_pos(hub,(g?764:260)-14,222-14);
        lv_obj_set_style_radius(hub,LV_RADIUS_CIRCLE,0); lv_obj_set_style_bg_color(hub,lv_color_hex(0x07101A),0);
        lv_obj_set_style_bg_opa(hub,LV_OPA_COVER,0); lv_obj_set_style_border_width(hub,3,0);
        lv_obj_set_style_border_color(hub,lv_color_hex(0x62798B),0);
    }

    /* Large live values centered in their own gauges. */
    drv_mph=driver_label(p,"0",126,232,268,80,&lv_font_montserrat_48,COL_VALUE,LV_TEXT_ALIGN_CENTER);
    lv_obj_set_style_transform_scale_x(drv_mph,384,0); lv_obj_set_style_transform_scale_y(drv_mph,384,0);
    driver_label(p,"MPH",188,326,144,36,&lv_font_montserrat_32,COL_LABEL,LV_TEXT_ALIGN_CENTER);
    drv_rpm=driver_label(p,"0",622,232,284,80,&lv_font_montserrat_48,COL_VALUE,LV_TEXT_ALIGN_CENTER);
    lv_obj_set_style_transform_scale_x(drv_rpm,384,0); lv_obj_set_style_transform_scale_y(drv_rpm,384,0);
    driver_label(p,"RPM",694,326,140,36,&lv_font_montserrat_32,COL_LABEL,LV_TEXT_ALIGN_CENTER);

    /* Lower factory pods: metallic shell + dark scale + dynamic illuminated arc. */
    driver_arc(p,36,386,338,180,0,180,20,0x07131E);
    driver_arc(p,650,386,338,180,0,180,20,0x07131E);
    driver_arc(p,43,393,324,180,0,180,3,0xAAB7C2);
    driver_arc(p,657,393,324,180,0,180,3,0xAAB7C2);
    driver_arc(p,55,405,300,180,0,180,10,0x17344A);
    driver_arc(p,669,405,300,180,0,180,10,0x17344A);
    drv_cool_arc=lv_arc_create(p); lv_obj_set_pos(drv_cool_arc,55,405); lv_obj_set_size(drv_cool_arc,300,300);
    lv_arc_set_rotation(drv_cool_arc,180); lv_arc_set_bg_angles(drv_cool_arc,0,90);
    lv_obj_remove_style(drv_cool_arc,NULL,LV_PART_KNOB); lv_obj_remove_style(drv_cool_arc,NULL,LV_PART_INDICATOR);
    lv_obj_set_style_arc_width(drv_cool_arc,7,LV_PART_MAIN); lv_obj_set_style_arc_color(drv_cool_arc,lv_color_hex(0x16BFFF),LV_PART_MAIN);
    lv_obj_set_style_bg_opa(drv_cool_arc,LV_OPA_TRANSP,0); lv_obj_clear_flag(drv_cool_arc,LV_OBJ_FLAG_CLICKABLE);
    drv_volt_arc=lv_arc_create(p); lv_obj_set_pos(drv_volt_arc,669,405); lv_obj_set_size(drv_volt_arc,300,300);
    lv_arc_set_rotation(drv_volt_arc,180); lv_arc_set_bg_angles(drv_volt_arc,0,120);
    lv_obj_remove_style(drv_volt_arc,NULL,LV_PART_KNOB); lv_obj_remove_style(drv_volt_arc,NULL,LV_PART_INDICATOR);
    lv_obj_set_style_arc_width(drv_volt_arc,7,LV_PART_MAIN); lv_obj_set_style_arc_color(drv_volt_arc,lv_color_hex(COL_GREEN),LV_PART_MAIN);
    lv_obj_set_style_bg_opa(drv_volt_arc,LV_OPA_TRANSP,0); lv_obj_clear_flag(drv_volt_arc,LV_OBJ_FLAG_CLICKABLE);

    drv_cool=driver_label(p,"--- F",88,472,235,54,&lv_font_montserrat_48,COL_VALUE,LV_TEXT_ALIGN_CENTER);
    driver_label(p,"WATER TEMP",82,527,248,28,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_CENTER);
    drv_volts=driver_label(p,"--.- V",700,472,260,54,&lv_font_montserrat_48,COL_VALUE,LV_TEXT_ALIGN_CENTER);
    driver_label(p,"VOLTS",752,527,155,28,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_CENTER);

    /* Center 4L60E commanded-gear pod: only the 1-4 value the PCM can actually report. */
    lv_obj_t *pod=lv_obj_create(p); lv_obj_remove_style_all(pod); lv_obj_set_pos(pod,365,442); lv_obj_set_size(pod,294,104);
    lv_obj_set_style_radius(pod,14,0); lv_obj_set_style_bg_color(pod,lv_color_hex(0x06101A),0); lv_obj_set_style_bg_opa(pod,LV_OPA_COVER,0);
    lv_obj_set_style_border_width(pod,2,0); lv_obj_set_style_border_color(pod,lv_color_hex(0x0E8FE8),0);
    for(int g=0;g<4;g++){
        drv_gear_box[g]=lv_obj_create(pod); lv_obj_remove_style_all(drv_gear_box[g]);
        lv_obj_set_pos(drv_gear_box[g],12+g*70,14); lv_obj_set_size(drv_gear_box[g],60,60);
        lv_obj_set_style_radius(drv_gear_box[g],9,0); lv_obj_set_style_bg_color(drv_gear_box[g],lv_color_hex(0x07131E),0);
        lv_obj_set_style_bg_opa(drv_gear_box[g],LV_OPA_COVER,0); lv_obj_set_style_border_width(drv_gear_box[g],2,0);
        lv_obj_set_style_border_color(drv_gear_box[g],lv_color_hex(0x0E6FAF),0);
        char gb[2]={(char)('1'+g),0};
        driver_label(drv_gear_box[g],gb,0,8,60,44,&lv_font_montserrat_32,COL_VALUE,LV_TEXT_ALIGN_CENTER);
    }
    drv_gear=NULL;
    driver_label(p,"GEAR",462,542,100,24,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_CENTER);
    l1_status=driver_label(p,"Offline",430,570,164,22,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_CENTER);

    /* Driver page touch navigation without adding visible boxes to the approved layout. */
    lv_obj_t *drv_next=lv_button_create(p); lv_obj_remove_style_all(drv_next);
    lv_obj_set_pos(drv_next,964,0); lv_obj_set_size(drv_next,60,600);
    lv_obj_set_style_bg_opa(drv_next,LV_OPA_TRANSP,0);
    lv_obj_add_event_cb(drv_next,nav_cb,LV_EVENT_PRESSED,(void*)(intptr_t)1);

    for(int i=0;i<8;i++){p1_title[i]=NULL;p1_value[i]=NULL;}
    l1_mph=drv_mph; l1_rpm=drv_rpm;
    driver_needle_set(drv_speed_needle,drv_speed_pts,260,222,156,0,160);
    driver_needle_set(drv_rpm_needle,drv_rpm_pts,764,222,156,0,7000);
}

static void build_page2(void)
{
    lv_obj_t *p = pages[1] = lv_obj_create(NULL);
    lv_obj_remove_style_all(p);
    lv_obj_set_style_bg_color(p, lv_color_hex(COL_BG), 0);
    lv_obj_set_style_bg_opa(p, LV_OPA_COVER, 0);

    lv_obj_t *title = lv_label_create(p);
    l2_page_title = title;
    lv_label_set_text(title, "DATA");
    lv_obj_set_pos(title, 32, 16);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_32, 0);
    lv_obj_set_style_text_color(title, lv_color_hex(COL_VALUE), 0);

    /* 4x4 grid of every live PID, GM 411-friendly (both banks' trims included) */
    int cw = 234, ch = 110, gx = 8, gy = 8, x0 = 32, y0 = 64;
    lv_obj_t **cell_out[4][4] = {
        { &l2_rpm,   &l2_mph,   &l2_load,  &l2_map   },
        { &l2_maf,   &l2_tps,   &l2_iat,   &l2_ect   },
        { &l2_afr,   &l2_timing,&l2_stft1, &l2_ltft1 },
        { &l2_stft2, &l2_ltft2, &l2_fuel,  &l2_volts },
    };
    const char *cell_title[4][4] = {
        { "RPM",   "MPH",     "LOAD %",  "MAP kPa" },
        { "MAF g/s","TPS %",  "IAT F",   "COOLANT F" },
        { "AFR",   "TIMING",  "STFT1 %", "LTFT1 %" },
        { "STFT2 %","LTFT2 %","FUEL %",  "BATTERY" },
    };
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 4; c++) {
            int x = x0 + c * (cw + gx);
            int y = y0 + r * (ch + gy);
            int idx = r * 4 + c;
            card(p, x, y, cw, ch, 0, false, cell_title[r][c], &p2_title[idx], cell_out[r][c]);
            p2_value[idx] = *cell_out[r][c];
        }
    }

    nav_row(p, 0, 2, 2);
}

static void clear_cb(lv_event_t *e)
{
    (void)e;
    int64_t now = esp_timer_get_time();
    if (now > s_clear_confirm_deadline_us) {
        s_clear_confirm_deadline_us = now + 5000000LL;
        if (l3_clear_label) lv_label_set_text(l3_clear_label, "PRESS AGAIN TO RESET");
        if (l3_status) lv_label_set_text(l3_status, "IGNITION ON / ENGINE OFF - press RESET again");
        sd_logger_event("DTC", "RESET CODES armed for 5 seconds");
        return;
    }
    s_clear_confirm_deadline_us = 0;
    if (l3_clear_label) lv_label_set_text(l3_clear_label, "RESET CODES");
    sd_logger_event("DTC", "RESET CODES confirmed");
    obd_auto_request_clear_dtcs();
}

static void refresh_cb(lv_event_t *e)
{
    (void)e;
    s_clear_confirm_deadline_us = 0;
    if (l3_clear_label) lv_label_set_text(l3_clear_label, "RESET CODES");
    sd_logger_event("DTC", "READ CODES pressed");
    obd_auto_request_dtc_refresh();
}

static void build_page3(void)
{
    lv_obj_t *p = pages[2] = lv_obj_create(NULL);
    lv_obj_remove_style_all(p);
    lv_obj_set_style_bg_color(p, lv_color_hex(COL_BG), 0);
    lv_obj_set_style_bg_opa(p, LV_OPA_COVER, 0);

    lv_obj_t *title = lv_label_create(p);
    lv_label_set_text(title, "CODES");
    lv_obj_set_pos(title, 32, 16);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_32, 0);
    lv_obj_set_style_text_color(title, lv_color_hex(COL_VALUE), 0);

    lv_obj_t *status_bar = lv_obj_create(p);
    lv_obj_remove_style_all(status_bar);
    lv_obj_set_pos(status_bar, 32, 64);
    lv_obj_set_size(status_bar, 960, 34);
    lv_obj_set_style_border_width(status_bar, 1, 0);
    lv_obj_set_style_border_color(status_bar, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_radius(status_bar, 10, 0);
    lv_obj_set_style_bg_opa(status_bar, LV_OPA_TRANSP, 0);
    l3_status = lv_label_create(status_bar);
    lv_label_set_text(l3_status, "Offline");
    lv_obj_set_pos(l3_status, 0, 0);
    lv_obj_set_size(l3_status, 960, 34);
    lv_obj_set_style_text_align(l3_status, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_text_font(l3_status, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l3_status, lv_color_hex(COL_VALUE), 0);

    lv_obj_t *panel = lv_obj_create(p);
    lv_obj_remove_style_all(panel);
    lv_obj_set_pos(panel, 32, 112);
    lv_obj_set_size(panel, 960, 300);
    lv_obj_set_style_bg_color(panel, lv_color_hex(COL_CARD_BG), 0);
    lv_obj_set_style_bg_opa(panel, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(panel, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_border_width(panel, 1, 0);
    lv_obj_set_style_radius(panel, 16, 0);
    lv_obj_set_scroll_dir(panel, LV_DIR_VER);

    l3_dtccount = lv_label_create(panel);
    lv_label_set_text(l3_dtccount, "DTC COUNT: 0");
    lv_obj_set_pos(l3_dtccount, 20, 18);
    lv_obj_set_style_text_font(l3_dtccount, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l3_dtccount, lv_color_hex(COL_LABEL), 0);

    l3_dtcs = lv_label_create(panel);
    lv_label_set_text(l3_dtcs, "No codes stored");
    lv_obj_set_pos(l3_dtcs, 20, 60);
    lv_obj_set_width(l3_dtcs, 900);
    lv_obj_set_height(l3_dtcs, LV_SIZE_CONTENT);
    lv_label_set_long_mode(l3_dtcs, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_text_font(l3_dtcs, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l3_dtcs, lv_color_hex(COL_VALUE), 0);

    lv_obj_t *r = lv_button_create(p);
    lv_obj_set_pos(r, 32, 428);
    lv_obj_set_size(r, 460, 64);
    lv_obj_add_event_cb(r, refresh_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_t *rl = lv_label_create(r);
    lv_label_set_text(rl, "READ CODES");
    lv_obj_clear_flag(rl, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_text_font(rl, &lv_font_montserrat_24, 0);
    lv_obj_center(rl);

    lv_obj_t *cbtn = lv_button_create(p);
    lv_obj_set_pos(cbtn, 524, 428);
    lv_obj_set_size(cbtn, 460, 64);
    lv_obj_set_style_bg_color(cbtn, lv_color_hex(0x8E1B1B), 0);
    lv_obj_add_event_cb(cbtn, clear_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_t *cl = lv_label_create(cbtn);
    l3_clear_label = cl;
    lv_label_set_text(cl, "RESET CODES");
    lv_obj_clear_flag(cl, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_text_font(cl, &lv_font_montserrat_24, 0);
    lv_obj_center(cl);

    nav_row(p, 1, 3, 3);
}


static void log_refresh_view(void)
{
    if (!l4_log || !l4_status) return;
    static char tail[4096];
    size_t n = sd_logger_read_tail(tail, sizeof(tail));
    if (!sd_logger_ready()) {
        lv_label_set_text(l4_status, "SD NOT MOUNTED - logging unavailable");
        lv_label_set_text(l4_log, "Insert a FAT/FAT32 microSD card and reboot.");
        return;
    }
    lv_label_set_text(l4_status, sd_logger_enabled() ? "SD LOGGING: ON   /sdcard/obd2.log" : "SD LOGGING: PAUSED   /sdcard/obd2.log");
    if (l4_toggle_label) lv_label_set_text(l4_toggle_label, sd_logger_enabled() ? "LOG OFF" : "LOG ON");
    lv_label_set_text(l4_log, n ? tail : "(log is empty)");
}

static void log_toggle_cb(lv_event_t *e)
{
    (void)e;
    sd_logger_set_enabled(!sd_logger_enabled());
    log_refresh_view();
}

static void log_refresh_cb(lv_event_t *e)
{
    (void)e;
    log_refresh_view();
}

static void log_clear_cb(lv_event_t *e)
{
    (void)e;
    sd_logger_clear();
    log_refresh_view();
}

static void log_rotate_cb(lv_event_t *e)
{
    (void)e;
    sd_logger_rotate_now();
    log_refresh_view();
}

static lv_obj_t *log_button(lv_obj_t *p, int x, int w, const char *txt, lv_event_cb_t cb, uint32_t color)
{
    /* The visible button is the touch target; no invisible padding/overlay. */
    lv_obj_t *b = lv_button_create(p);
    lv_obj_set_pos(b, x, 472);
    lv_obj_set_size(b, w, 60);
    lv_obj_set_style_bg_color(b, lv_color_hex(color), 0);
    lv_obj_set_style_bg_opa(b, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(b, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_border_width(b, 1, 0);
    lv_obj_set_style_radius(b, 10, 0);
    lv_obj_clear_flag(b, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(b, cb, LV_EVENT_PRESSED, NULL);

    lv_obj_t *l = lv_label_create(b);
    lv_label_set_text(l, txt);
    lv_obj_set_style_text_font(l, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(COL_VALUE), 0);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_center(l);
    return l;
}

static void settings_refresh(void)
{
    char b[32];
    if(set_brightness_label){snprintf(b,sizeof(b),"%d%%",s_brightness_pct);lv_label_set_text(set_brightness_label,b);}
    if(set_smoothing_label) lv_label_set_text(set_smoothing_label,s_smoothing?"ON":"OFF");
    if(set_sweep_label) lv_label_set_text(set_sweep_label,s_startup_sweep?"ON":"OFF");
}
static void brightness_cb(lv_event_t *e)
{
    int delta=(int)(intptr_t)lv_event_get_user_data(e);
    s_brightness_pct+=delta;if(s_brightness_pct<10)s_brightness_pct=10;if(s_brightness_pct>100)s_brightness_pct=100;
    bsp_display_brightness_set(s_brightness_pct);
    settings_refresh();
}
static void smoothing_cb(lv_event_t *e){(void)e;s_smoothing=!s_smoothing;settings_refresh();}
static void sweep_cb(lv_event_t *e){(void)e;s_startup_sweep=!s_startup_sweep;settings_refresh();}
static lv_obj_t *settings_button(lv_obj_t *p,int x,int y,int w,const char *txt,lv_event_cb_t cb,intptr_t arg)
{
    lv_obj_t *b=lv_button_create(p);lv_obj_set_pos(b,x,y);lv_obj_set_size(b,w,58);
    lv_obj_set_style_bg_color(b,lv_color_hex(0x0A2740),0);lv_obj_set_style_border_color(b,lv_color_hex(0x0E8FE8),0);
    lv_obj_set_style_border_width(b,2,0);lv_obj_set_style_radius(b,10,0);lv_obj_add_event_cb(b,cb,LV_EVENT_PRESSED,(void*)arg);
    lv_obj_t *l=lv_label_create(b);lv_label_set_text(l,txt);lv_obj_set_style_text_font(l,&lv_font_montserrat_24,0);
    lv_obj_set_style_text_color(l,lv_color_hex(COL_VALUE),0);lv_obj_clear_flag(l,LV_OBJ_FLAG_CLICKABLE);lv_obj_center(l);return b;
}
static void build_page4(void)
{
    lv_obj_t *p=pages[3]=lv_obj_create(NULL);lv_obj_remove_style_all(p);
    lv_obj_set_style_bg_color(p,lv_color_hex(0x02060B),0);lv_obj_set_style_bg_opa(p,LV_OPA_COVER,0);
    driver_label(p,"SETTINGS",32,18,300,44,&lv_font_montserrat_32,COL_VALUE,LV_TEXT_ALIGN_LEFT);
    driver_label(p,"DISPLAY / DRIVER",700,24,290,34,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_RIGHT);

    lv_obj_t *a=lv_obj_create(p);lv_obj_set_pos(a,32,78);lv_obj_set_size(a,465,410);
    lv_obj_set_style_bg_color(a,lv_color_hex(0x06101A),0);lv_obj_set_style_border_color(a,lv_color_hex(0x0E6FAF),0);
    lv_obj_set_style_border_width(a,2,0);lv_obj_set_style_radius(a,14,0);
    driver_label(a,"DISPLAY",20,16,200,32,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    driver_label(a,"BRIGHTNESS",20,78,200,30,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    set_brightness_label=driver_label(a,"82%",300,70,120,44,&lv_font_montserrat_32,COL_VALUE,LV_TEXT_ALIGN_RIGHT);
    settings_button(a,20,130,190,"- DIM",brightness_cb,-10);settings_button(a,235,130,190,"+ BRIGHT",brightness_cb,10);
    driver_label(a,"UNITS",20,220,160,30,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    driver_label(a,"MPH / F / PSI",220,216,205,34,&lv_font_montserrat_24,COL_VALUE,LV_TEXT_ALIGN_RIGHT);
    driver_label(a,"STARTUP SPLASH",20,282,220,30,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    driver_label(a,"3 SEC",300,278,125,34,&lv_font_montserrat_24,COL_VALUE,LV_TEXT_ALIGN_RIGHT);

    lv_obj_t *b=lv_obj_create(p);lv_obj_set_pos(b,527,78);lv_obj_set_size(b,465,410);
    lv_obj_set_style_bg_color(b,lv_color_hex(0x06101A),0);lv_obj_set_style_border_color(b,lv_color_hex(0x0E6FAF),0);
    lv_obj_set_style_border_width(b,2,0);lv_obj_set_style_radius(b,14,0);
    driver_label(b,"DRIVER",20,16,200,32,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    driver_label(b,"NEEDLE SMOOTHING",20,80,260,30,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    set_smoothing_label=driver_label(b,"ON",330,74,90,40,&lv_font_montserrat_32,COL_GREEN,LV_TEXT_ALIGN_RIGHT);
    settings_button(b,20,125,400,"TOGGLE SMOOTHING",smoothing_cb,0);
    driver_label(b,"STARTUP SWEEP",20,220,240,30,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    set_sweep_label=driver_label(b,"ON",330,214,90,40,&lv_font_montserrat_32,COL_GREEN,LV_TEXT_ALIGN_RIGHT);
    settings_button(b,20,265,400,"TOGGLE STARTUP SWEEP",sweep_cb,0);
    driver_label(b,"WARN: COOLANT 230F / VOLTS 11.5-15.2",20,350,410,26,&lv_font_montserrat_24,COL_LABEL,LV_TEXT_ALIGN_LEFT);
    nav_row(p,2,0,4);settings_refresh();
}


static void oem_profile_cb(lv_event_t *e)
{
    obd_oem_profile_t profile = (obd_oem_profile_t)(intptr_t)lv_event_get_user_data(e);
    obd_auto_set_oem_profile(profile);
}

static void oem_scan_cb(lv_event_t *e)
{
    (void)e;
    sd_logger_event("OEM", "READ-ONLY SCAN pressed");
    obd_auto_request_oem_scan();
}

static lv_obj_t *oem_button(lv_obj_t *p, int x, int y, int w, const char *txt,
                            obd_oem_profile_t profile, uint32_t color)
{
    lv_obj_t *b = lv_button_create(p);
    lv_obj_set_pos(b, x, y);
    lv_obj_set_size(b, w, 58);
    lv_obj_set_style_bg_color(b, lv_color_hex(color), 0);
    lv_obj_set_style_bg_opa(b, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(b, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_border_width(b, 1, 0);
    lv_obj_set_style_radius(b, 10, 0);
    lv_obj_clear_flag(b, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_event_cb(b, oem_profile_cb, LV_EVENT_PRESSED, (void *)(intptr_t)profile);
    lv_obj_t *l = lv_label_create(b);
    lv_label_set_text(l, txt);
    lv_obj_set_style_text_font(l, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(COL_VALUE), 0);
    lv_obj_clear_flag(l, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_center(l);
    return b;
}

static void build_page5(void)
{
    lv_obj_t *p = pages[4] = lv_obj_create(NULL);
    lv_obj_remove_style_all(p);
    lv_obj_set_style_bg_color(p, lv_color_hex(COL_BG), 0);
    lv_obj_set_style_bg_opa(p, LV_OPA_COVER, 0);

    lv_obj_t *title = lv_label_create(p);
    lv_label_set_text(title, "OEM DIAGNOSTICS - READ ONLY");
    lv_obj_set_pos(title, 32, 16);
    lv_obj_set_style_text_font(title, &lv_font_montserrat_32, 0);
    lv_obj_set_style_text_color(title, lv_color_hex(COL_VALUE), 0);

    l5_adapter = lv_label_create(p);
    lv_obj_set_pos(l5_adapter, 32, 62);
    lv_obj_set_size(l5_adapter, 960, 32);
    lv_obj_set_style_text_font(l5_adapter, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l5_adapter, lv_color_hex(COL_LABEL), 0);
    lv_label_set_text(l5_adapter, "ADAPTER: detecting...");

    l5_caps = lv_label_create(p);
    lv_obj_set_pos(l5_caps, 32, 94);
    lv_obj_set_size(l5_caps, 960, 32);
    lv_obj_set_style_text_font(l5_caps, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l5_caps, lv_color_hex(COL_LABEL), 0);
    lv_label_set_text(l5_caps, "CAPS: --");

    oem_button(p, 32, 138, 176, "FORD", OBD_OEM_FORD, 0x23415C);
    oem_button(p, 224, 138, 176, "GM", OBD_OEM_GM, 0x23415C);
    oem_button(p, 416, 138, 192, "CHRY/JEEP", OBD_OEM_CHRYSLER_JEEP, 0x23415C);
    oem_button(p, 624, 138, 176, "BMW", OBD_OEM_BMW, 0x23415C);
    oem_button(p, 816, 138, 176, "RANGE ROVER", OBD_OEM_LAND_ROVER, 0x23415C);

    lv_obj_t *panel = lv_obj_create(p);
    lv_obj_set_pos(panel, 32, 212);
    lv_obj_set_size(panel, 960, 250);
    lv_obj_set_style_bg_color(panel, lv_color_hex(COL_CARD_BG), 0);
    lv_obj_set_style_bg_opa(panel, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(panel, lv_color_hex(COL_CARD_BORDER), 0);
    lv_obj_set_style_border_width(panel, 1, 0);
    lv_obj_set_style_radius(panel, 12, 0);

    l5_profile = lv_label_create(panel);
    lv_obj_set_pos(l5_profile, 16, 14);
    lv_obj_set_size(l5_profile, 900, 30);
    lv_obj_set_style_text_font(l5_profile, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l5_profile, lv_color_hex(COL_VALUE), 0);
    lv_label_set_text(l5_profile, "PROFILE: NONE");

    l5_status = lv_label_create(panel);
    lv_obj_set_pos(l5_status, 16, 50);
    lv_obj_set_size(l5_status, 900, 30);
    lv_obj_set_style_text_font(l5_status, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l5_status, lv_color_hex(COL_MPH), 0);
    lv_label_set_text(l5_status, "STATUS: IDLE");

    l5_result = lv_label_create(panel);
    lv_obj_set_pos(l5_result, 16, 88);
    lv_obj_set_size(l5_result, 900, 142);
    lv_label_set_long_mode(l5_result, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_text_font(l5_result, &lv_font_montserrat_24, 0);
    lv_obj_set_style_text_color(l5_result, lv_color_hex(COL_VALUE), 0);
    lv_label_set_text(l5_result, "Select a manufacturer. The scan is read-only and does not code/program modules.");

    lv_obj_t *scan = lv_button_create(p);
    lv_obj_set_pos(scan, 332, 474);
    lv_obj_set_size(scan, 360, 60);
    lv_obj_set_style_bg_color(scan, lv_color_hex(0x1C5B3A), 0);
    lv_obj_set_style_radius(scan, 10, 0);
    lv_obj_add_event_cb(scan, oem_scan_cb, LV_EVENT_PRESSED, NULL);
    lv_obj_t *sl = lv_label_create(scan);
    lv_label_set_text(sl, "READ-ONLY SCAN");
    lv_obj_set_style_text_font(sl, &lv_font_montserrat_24, 0);
    lv_obj_clear_flag(sl, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_center(sl);

    nav_row(p, 2, 3, 5);
}

static void text_if(lv_obj_t *o, const char *s)
{
    if (o && strcmp(lv_label_get_text(o), s)) lv_label_set_text(o, s);
}


static void set_speed_digits(float mph)
{
    static const uint8_t mask[10] = {
        0x3F, /* 0: a b c d e f */
        0x06, /* 1: b c */
        0x5B, /* 2: a b d e g */
        0x4F, /* 3: a b c d g */
        0x66, /* 4: b c f g */
        0x6D, /* 5: a c d f g */
        0x7D, /* 6: a c d e f g */
        0x07, /* 7: a b c */
        0x7F, /* 8: all */
        0x6F  /* 9: a b c d f g */
    };
    int v = (int)(mph + 0.5f);
    if (v < 0) v = 0;
    if (v > 999) v = 999;

    int count = (v >= 100) ? 3 : (v >= 10 ? 2 : 1);
    int vals[3] = { (v / 100) % 10, (v / 10) % 10, v % 10 };
    int first = 3 - count;
    int total_w = count * 100 + (count - 1) * 12;
    int x0 = (360 - total_w) / 2;

    for (int d = 0; d < 3; d++) {
        if (d < first) {
            lv_obj_add_flag(mph_digit[d], LV_OBJ_FLAG_HIDDEN);
            continue;
        }
        lv_obj_remove_flag(mph_digit[d], LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_pos(mph_digit[d], x0 + (d - first) * 112, 8);
        uint8_t m = mask[vals[d]];
        for (int k = 0; k < 7; k++) {
            if (m & (1u << k)) lv_obj_remove_flag(mph_seg[d][k], LV_OBJ_FLAG_HIDDEN);
            else lv_obj_add_flag(mph_seg[d][k], LV_OBJ_FLAG_HIDDEN);
        }
    }
}

static void update_shift_bar(int rpm)
{
    static const uint32_t zone[N_SEGS] = {
        COL_GREEN, COL_GREEN, COL_GREEN, COL_GREEN,
        COL_YELLOW, COL_YELLOW, COL_YELLOW,
        COL_ORANGE, COL_ORANGE,
        COL_RED, COL_RED
    };
    int lit = (rpm * N_SEGS) / RPM_REDLINE;
    if (lit < 0) lit = 0;
    if (lit > N_SEGS) lit = N_SEGS;
    for (int i = 0; i < N_SEGS; i++) {
        lv_obj_set_style_bg_color(seg[i], lv_color_hex(i < lit ? zone[i] : COL_SEG_DIM), 0);
    }
}

typedef enum {
    M_MAP, M_TPS, M_LOAD, M_MAF, M_COOLANT, M_BATTERY, M_FUEL, M_TIMING,
    M_IAT, M_STFT1, M_LTFT1, M_STFT2, M_LTFT2, M_AFR, M_RUNTIME,
    M_FUEL_PRESSURE, M_DIST_MIL, M_EGR_CMD, M_EGR_ERR, M_EVAP_PURGE,
    M_WARMUPS, M_DIST_CLEAR, M_BARO, M_MODULE_V, M_REL_TPS, M_AMBIENT,
    M_CMD_THR, M_ETHANOL, M_ABS_LOAD, M_THR_B, M_THR_C, M_PEDAL_D, M_PEDAL_E,
    M_PEDAL_F, M_REL_ACCEL, M_OIL_TEMP, M_INJ_TIMING, M_FUEL_RATE,
    M_DEMAND_TQ, M_ACTUAL_TQ, M_REF_TQ, M_OBD_STD, M_FUEL_TYPE,
    M_FUEL_RAIL, M_FUEL_RAIL_ABS, M_CAT_B1S1, M_CAT_B2S1, M_CAT_B1S2, M_CAT_B2S2,
    M_MIL_TIME, M_CLEAR_TIME, M_EVAP_VAPOR, M_HYBRID_BATT, M_ACTUAL_AFR,
    M_GEAR, M_OIL_PRESSURE, M_COUNT
} live_metric_t;

static bool ui_pid_valid(const obd_data_t *d, uint8_t pid)
{
    if (!d || pid == 0 || pid > 0xC0) return false;
    unsigned block = (pid - 1u) / 32u;
    unsigned offset = (pid - 1u) % 32u;
    if (block >= 6) return false;
    return (d->pid_valid[block] & (1u << (31u - offset))) != 0;
}

static bool metric_available(const obd_data_t *d, live_metric_t m)
{
    switch (m) {
    case M_MAP: return ui_pid_valid(d,0x0B); case M_TPS: return ui_pid_valid(d,0x11);
    case M_LOAD: return ui_pid_valid(d,0x04); case M_MAF: return ui_pid_valid(d,0x10);
    case M_COOLANT: return ui_pid_valid(d,0x05); case M_BATTERY: return d->volts > 5.0f;
    case M_FUEL: return ui_pid_valid(d,0x2F); case M_TIMING: return ui_pid_valid(d,0x0E);
    case M_IAT: return ui_pid_valid(d,0x0F); case M_STFT1: return ui_pid_valid(d,0x06);
    case M_LTFT1: return ui_pid_valid(d,0x07); case M_STFT2: return ui_pid_valid(d,0x08);
    case M_LTFT2: return ui_pid_valid(d,0x09); case M_AFR: return ui_pid_valid(d,0x44);
    case M_RUNTIME: return ui_pid_valid(d,0x1F); case M_FUEL_PRESSURE: return ui_pid_valid(d,0x0A);
    case M_DIST_MIL: return ui_pid_valid(d,0x21); case M_EGR_CMD: return ui_pid_valid(d,0x2C);
    case M_EGR_ERR: return ui_pid_valid(d,0x2D); case M_EVAP_PURGE: return ui_pid_valid(d,0x2E);
    case M_WARMUPS: return ui_pid_valid(d,0x30); case M_DIST_CLEAR: return ui_pid_valid(d,0x31);
    case M_BARO: return ui_pid_valid(d,0x33); case M_MODULE_V: return ui_pid_valid(d,0x42);
    case M_REL_TPS: return ui_pid_valid(d,0x45); case M_AMBIENT: return ui_pid_valid(d,0x46);
    case M_CMD_THR: return ui_pid_valid(d,0x4C); case M_ETHANOL: return ui_pid_valid(d,0x52);
    case M_ABS_LOAD: return ui_pid_valid(d,0x43); case M_THR_B: return ui_pid_valid(d,0x47);
    case M_THR_C: return ui_pid_valid(d,0x48); case M_PEDAL_D: return ui_pid_valid(d,0x49);
    case M_PEDAL_E: return ui_pid_valid(d,0x4A); case M_PEDAL_F: return ui_pid_valid(d,0x4B);
    case M_REL_ACCEL: return ui_pid_valid(d,0x5A); case M_OIL_TEMP: return ui_pid_valid(d,0x5C);
    case M_INJ_TIMING: return ui_pid_valid(d,0x5D); case M_FUEL_RATE: return ui_pid_valid(d,0x5E);
    case M_DEMAND_TQ: return ui_pid_valid(d,0x61); case M_ACTUAL_TQ: return ui_pid_valid(d,0x62);
    case M_REF_TQ: return ui_pid_valid(d,0x63); case M_OBD_STD: return ui_pid_valid(d,0x1C);
    case M_FUEL_TYPE: return ui_pid_valid(d,0x51);
    case M_FUEL_RAIL: return ui_pid_valid(d,0x23); case M_FUEL_RAIL_ABS: return ui_pid_valid(d,0x59);
    case M_CAT_B1S1: return ui_pid_valid(d,0x3C); case M_CAT_B2S1: return ui_pid_valid(d,0x3D);
    case M_CAT_B1S2: return ui_pid_valid(d,0x3E); case M_CAT_B2S2: return ui_pid_valid(d,0x3F);
    case M_MIL_TIME: return ui_pid_valid(d,0x4D); case M_CLEAR_TIME: return ui_pid_valid(d,0x4E);
    case M_EVAP_VAPOR: return ui_pid_valid(d,0x54); case M_HYBRID_BATT: return ui_pid_valid(d,0x5B);
    case M_ACTUAL_AFR: return d->actual_afr > 0.1f;
    case M_GEAR: return d->gear_valid; case M_OIL_PRESSURE: return d->oil_pressure_valid;
    default: return false;
    }
}

static const char *metric_title(live_metric_t m)
{
    static const char *t[M_COUNT] = {
        "MAP kPa","THROTTLE %","ENG LOAD %","MAF g/s","COOLANT F","BATTERY V","FUEL %","TIMING deg",
        "IAT F","STFT1 %","LTFT1 %","STFT2 %","LTFT2 %","AFR","RUN TIME s",
        "FUEL PRESS kPa","MIL DIST km","EGR CMD %","EGR ERR %","EVAP PURGE %",
        "WARMUPS","CLEAR DIST km","BARO kPa","MODULE V","REL TPS %","AMBIENT F",
        "CMD THR %","ETHANOL %","ABS LOAD %","THROTTLE B %","THROTTLE C %","PEDAL D %","PEDAL E %",
        "PEDAL F %","REL PEDAL %","OIL TEMP F","INJ TIMING deg","FUEL RATE L/h",
        "DEMAND TQ %","ACTUAL TQ %","REF TQ Nm","OBD STD","FUEL TYPE",
        "FUEL RAIL kPa","RAIL ABS kPa","CAT B1S1 F","CAT B2S1 F","CAT B1S2 F","CAT B2S2 F",
        "MIL TIME min","CLEAR TIME min","EVAP Pa","HYBRID BATT %","ACT AFR","GEAR","OIL PSI"
    };
    return (m >= 0 && m < M_COUNT) ? t[m] : "DATA";
}

static void metric_value(const obd_data_t *d, live_metric_t m, char *b, size_t n)
{
    switch (m) {
    case M_MAP: snprintf(b,n,"%.0f",d->map_kpa); break; case M_TPS: snprintf(b,n,"%.1f",d->tps); break;
    case M_LOAD: snprintf(b,n,"%.1f",d->load); break; case M_MAF: snprintf(b,n,"%.2f",d->maf_gps); break;
    case M_COOLANT: snprintf(b,n,"%.0f",d->ect_f); break; case M_BATTERY: snprintf(b,n,"%.2f",d->volts); break;
    case M_FUEL: snprintf(b,n,"%.1f",d->fuel_pct); break; case M_TIMING: snprintf(b,n,"%.1f",d->timing_deg); break;
    case M_IAT: snprintf(b,n,"%.0f",d->iat_f); break; case M_STFT1: snprintf(b,n,"%.1f",d->stft1); break;
    case M_LTFT1: snprintf(b,n,"%.1f",d->ltft1); break; case M_STFT2: snprintf(b,n,"%.1f",d->stft2); break;
    case M_LTFT2: snprintf(b,n,"%.1f",d->ltft2); break; case M_AFR: snprintf(b,n,"%.2f",d->afr); break;
    case M_RUNTIME: snprintf(b,n,"%lu",(unsigned long)d->runtime_s); break;
    case M_FUEL_PRESSURE: snprintf(b,n,"%.0f",d->fuel_pressure_kpa); break;
    case M_DIST_MIL: snprintf(b,n,"%lu",(unsigned long)d->distance_mil_km); break;
    case M_EGR_CMD: snprintf(b,n,"%.1f",d->egr_cmd_pct); break; case M_EGR_ERR: snprintf(b,n,"%.1f",d->egr_error_pct); break;
    case M_EVAP_PURGE: snprintf(b,n,"%.1f",d->evap_purge_pct); break;
    case M_WARMUPS: snprintf(b,n,"%lu",(unsigned long)d->warmups_since_clear); break;
    case M_DIST_CLEAR: snprintf(b,n,"%lu",(unsigned long)d->distance_clear_km); break;
    case M_BARO: snprintf(b,n,"%.0f",d->baro_kpa); break; case M_MODULE_V: snprintf(b,n,"%.2f",d->control_module_v); break;
    case M_REL_TPS: snprintf(b,n,"%.1f",d->relative_tps); break; case M_AMBIENT: snprintf(b,n,"%.0f",d->ambient_f); break;
    case M_CMD_THR: snprintf(b,n,"%.1f",d->cmd_throttle_pct); break; case M_ETHANOL: snprintf(b,n,"%.1f",d->ethanol_pct); break;
    case M_ABS_LOAD: snprintf(b,n,"%.1f",d->abs_load_pct); break; case M_THR_B: snprintf(b,n,"%.1f",d->throttle_b_pct); break;
    case M_THR_C: snprintf(b,n,"%.1f",d->throttle_c_pct); break; case M_PEDAL_D: snprintf(b,n,"%.1f",d->pedal_d_pct); break;
    case M_PEDAL_E: snprintf(b,n,"%.1f",d->pedal_e_pct); break; case M_PEDAL_F: snprintf(b,n,"%.1f",d->pedal_f_pct); break;
    case M_REL_ACCEL: snprintf(b,n,"%.1f",d->rel_accel_pct); break; case M_OIL_TEMP: snprintf(b,n,"%.0f",d->oil_temp_f); break;
    case M_INJ_TIMING: snprintf(b,n,"%.1f",d->injection_timing_deg); break; case M_FUEL_RATE: snprintf(b,n,"%.2f",d->fuel_rate_lph); break;
    case M_DEMAND_TQ: snprintf(b,n,"%.0f",d->demanded_torque_pct); break; case M_ACTUAL_TQ: snprintf(b,n,"%.0f",d->actual_torque_pct); break;
    case M_REF_TQ: snprintf(b,n,"%lu",(unsigned long)d->reference_torque_nm); break; case M_OBD_STD: snprintf(b,n,"%u",(unsigned)d->obd_standard); break;
    case M_FUEL_TYPE: snprintf(b,n,"%u",(unsigned)d->fuel_type); break;
    case M_FUEL_RAIL: snprintf(b,n,"%.0f",d->fuel_rail_kpa); break; case M_FUEL_RAIL_ABS: snprintf(b,n,"%.0f",d->fuel_rail_abs_kpa); break;
    case M_CAT_B1S1: snprintf(b,n,"%.0f",d->catalyst_b1s1_f); break; case M_CAT_B2S1: snprintf(b,n,"%.0f",d->catalyst_b2s1_f); break;
    case M_CAT_B1S2: snprintf(b,n,"%.0f",d->catalyst_b1s2_f); break; case M_CAT_B2S2: snprintf(b,n,"%.0f",d->catalyst_b2s2_f); break;
    case M_MIL_TIME: snprintf(b,n,"%lu",(unsigned long)d->mil_time_min); break; case M_CLEAR_TIME: snprintf(b,n,"%lu",(unsigned long)d->clear_time_min); break;
    case M_EVAP_VAPOR: snprintf(b,n,"%.0f",d->evap_vapor_pa); break; case M_HYBRID_BATT: snprintf(b,n,"%.1f",d->hybrid_battery_pct); break;
    case M_ACTUAL_AFR: snprintf(b,n,"%.2f",d->actual_afr); break;
    case M_GEAR: snprintf(b,n,"%d",d->gear); break; case M_OIL_PRESSURE: snprintf(b,n,"%.1f",d->oil_pressure_psi); break;
    default: snprintf(b,n,"N/A"); break;
    }
}

static const live_metric_t metric_priority[M_COUNT] = {
    M_MAP,M_TPS,M_LOAD,M_MAF,M_COOLANT,M_BATTERY,M_FUEL,M_TIMING,
    M_IAT,M_STFT1,M_LTFT1,M_AFR,M_STFT2,M_LTFT2,M_FUEL_PRESSURE,M_BARO,
    M_MODULE_V,M_REL_TPS,M_AMBIENT,M_CMD_THR,M_ABS_LOAD,M_THR_B,M_THR_C,
    M_PEDAL_D,M_PEDAL_E,M_PEDAL_F,M_REL_ACCEL,M_OIL_TEMP,M_INJ_TIMING,M_FUEL_RATE,
    M_DEMAND_TQ,M_ACTUAL_TQ,M_REF_TQ,M_FUEL_RAIL,M_FUEL_RAIL_ABS,M_ACTUAL_AFR,
    M_CAT_B1S1,M_CAT_B2S1,M_CAT_B1S2,M_CAT_B2S2,M_RUNTIME,M_DIST_MIL,M_MIL_TIME,M_CLEAR_TIME,
    M_EVAP_PURGE,M_EVAP_VAPOR,M_EGR_CMD,M_EGR_ERR,M_WARMUPS,M_DIST_CLEAR,M_ETHANOL,M_HYBRID_BATT,
    M_OBD_STD,M_FUEL_TYPE,M_GEAR,M_OIL_PRESSURE
};

static void update_dynamic_live_pages(const obd_data_t *d)
{
    bool used[M_COUNT] = {0};
    char v[64];
    int p1 = 0;
    int supported_metrics = 0;
    for (int i = 0; i < M_COUNT; ++i) if (metric_available(d, metric_priority[i])) supported_metrics++;

    /* Page 1 keeps the eight highest-priority supported driving values. */
    for (int i=0; i<M_COUNT && p1<8; ++i) {
        live_metric_t m=metric_priority[i];
        if (!metric_available(d,m)) continue;
        lv_label_set_text(p1_title[p1], metric_title(m));
        metric_value(d,m,v,sizeof(v)); lv_label_set_text(p1_value[p1],v);
        used[m]=true; p1++;
    }
    while (p1<8) { lv_label_set_text(p1_title[p1], "UNSUPPORTED"); lv_label_set_text(p1_value[p1], "N/A"); p1++; }

    /* Page 2 auto-pages through every remaining decoded/supported metric.  This
       prevents a vehicle with >24 useful parameters from silently losing the
       lower-priority ones.  Each bank remains visible for 7 seconds. */
    live_metric_t remaining[M_COUNT];
    int rem_count = 0;
    for (int i=0; i<M_COUNT; ++i) {
        live_metric_t m=metric_priority[i];
        if (!used[m] && metric_available(d,m)) remaining[rem_count++] = m;
    }
    int banks = rem_count > 0 ? (rem_count + 15) / 16 : 1;
    int bank = banks > 1 ? (int)((lv_tick_get() / 7000u) % (uint32_t)banks) : 0;
    int first = bank * 16;
    int p2 = 0;
    for (; p2 < 16 && first + p2 < rem_count; ++p2) {
        live_metric_t m = remaining[first + p2];
        lv_label_set_text(p2_title[p2], metric_title(m));
        metric_value(d,m,v,sizeof(v)); lv_label_set_text(p2_value[p2],v);
    }
    /* RPM/speed are always visible on Page 1; use spare Page 2 cells for them
       only when the vehicle has fewer than sixteen remaining metrics. */
    if (p2<16 && ui_pid_valid(d,0x0C)) { lv_label_set_text(p2_title[p2],"RPM"); snprintf(v,sizeof(v),"%d",d->rpm); lv_label_set_text(p2_value[p2++],v); }
    if (p2<16 && ui_pid_valid(d,0x0D)) { lv_label_set_text(p2_title[p2],"MPH"); snprintf(v,sizeof(v),"%.0f",d->mph); lv_label_set_text(p2_value[p2++],v); }
    while (p2<16) { lv_label_set_text(p2_title[p2],"NO MORE PIDS"); lv_label_set_text(p2_value[p2],"N/A"); p2++; }

    if (l2_page_title) {
        if (banks > 1) snprintf(v,sizeof(v),"DATA %d/%d  |  %d LIVE",bank+1,banks,supported_metrics+(ui_pid_valid(d,0x0C)?1:0)+(ui_pid_valid(d,0x0D)?1:0));
        else snprintf(v,sizeof(v),"DATA  |  %d LIVE",supported_metrics+(ui_pid_valid(d,0x0C)?1:0)+(ui_pid_valid(d,0x0D)?1:0));
        lv_label_set_text(l2_page_title,v);
    }
}

static const char *dtc_description(const char *code)
{
    if (!code || strlen(code) < 5) return "Diagnostic trouble code";

    /* Generic definitions currently seen on the user's Ford diesel.  Keep
       this table deliberately conservative: exact manufacturer-specific
       definitions should only be added when verified for that platform. */
    if (!strcmp(code, "P20B9"))
        return "Reductant Heater A Control Circuit/Open - DEF/SCR heater electrical circuit is open or has no expected voltage. Check heater, connector, wiring, fuse/relay; exact Heater A location is vehicle-specific.";
    if (!strcmp(code, "P20BA"))
        return "Reductant Heater A Control Circuit Performance - DEF/SCR heater circuit is responding outside the expected operating range. Check heater resistance/current, wiring/connectors, power supply and related control hardware.";

    switch (code[0]) {
        case 'P': return "Powertrain DTC - engine/transmission/emissions/fuel system. Exact definition depends on the remaining digits and, for manufacturer-specific codes, the vehicle service information.";
        case 'B': return "Body DTC - body, comfort, restraint or related module. Exact definition is usually manufacturer-specific.";
        case 'C': return "Chassis DTC - ABS, steering, suspension or related chassis module. Exact definition may be manufacturer-specific.";
        case 'U': return "Network/communication DTC - module communication or data-bus fault. Exact definition depends on vehicle/module.";
        default:  return "Diagnostic trouble code - see vehicle-specific service information for the exact definition.";
    }
}

static void append_text(char *out, size_t out_sz, const char *text)
{
    if (!out || !out_sz || !text) return;
    size_t used = strlen(out);
    if (used >= out_sz - 1) return;
    snprintf(out + used, out_sz - used, "%s", text);
}

static void format_dtc_details(const char *src, char *out, size_t out_sz)
{
    if (!out || !out_sz) return;
    out[0] = 0;
    if (!src || !src[0] || !strcmp(src, "-") || strstr(src, "No codes")) {
        snprintf(out, out_sz, "No codes reported");
        return;
    }

    static char copy[384];
    snprintf(copy, sizeof(copy), "%s", src);
    char *save = NULL;
    char *tok = strtok_r(copy, " \r\n", &save);
    const char *section = "";
    int detailed = 0;

    while (tok) {
        if (!strcmp(tok, "STORED:")) section = "STORED";
        else if (!strcmp(tok, "PENDING:")) section = "PENDING";
        else if (!strcmp(tok, "PERMANENT:")) section = "PERMANENT";
        else if (!strcmp(tok, "NONE")) { /* section has no codes */ }
        else if ((tok[0]=='P' || tok[0]=='B' || tok[0]=='C' || tok[0]=='U') && strlen(tok)==5) {
            static char line[640];
            const char *state_note = !strcmp(section,"PENDING") ? "Pending: detected but not yet confirmed; MIL may remain off. " :
                                     !strcmp(section,"PERMANENT") ? "Permanent: retained by emissions logic until monitor criteria are satisfied. " :
                                     !strcmp(section,"STORED") ? "Stored/confirmed fault. " : "";
            snprintf(line, sizeof(line), "%s %s  %s\n%s\n\n", section[0] ? section : "DTC", tok, state_note, dtc_description(tok));
            append_text(out, out_sz, line);
            detailed++;
        }
        tok = strtok_r(NULL, " \r\n", &save);
    }

    if (!detailed) snprintf(out, out_sz, "%s", src);
}

static void update_ui(const obd_data_t *d)
{
    char b[96];

    /* page 1 - Driver master screen */
    static float sm_mph=0.0f,sm_rpm=0.0f;
    float mph=d->mph,rpm=(float)d->rpm;
    if(s_smoothing){sm_mph += 0.28f*(mph-sm_mph); sm_rpm += 0.22f*(rpm-sm_rpm); mph=sm_mph; rpm=sm_rpm;}
    int64_t age_ms=(esp_timer_get_time()-s_ui_boot_us)/1000;
    if(s_startup_sweep && age_ms>=3000 && age_ms<4300){
        float q=(float)(age_ms-3000)/1300.0f; if(q<0.5f) q*=2.0f; else q=(1.0f-q)*2.0f;
        mph=160.0f*q; rpm=7000.0f*q;
    }
    snprintf(b,sizeof(b),"%.0f",mph); text_if(drv_mph,b);
    snprintf(b,sizeof(b),"%d",(int)rpm); text_if(drv_rpm,b);
    snprintf(b,sizeof(b),"%.0f F",d->ect_f); text_if(drv_cool,b);
    snprintf(b,sizeof(b),"%.1f V",d->volts); text_if(drv_volts,b);
    driver_needle_set(drv_speed_needle,drv_speed_pts,260,222,156,mph,160);
    driver_needle_set(drv_rpm_needle,drv_rpm_pts,764,222,156,rpm,7000);
    /* Lower illuminated arcs are live too: coolant 100-260 F, voltage 10-16 V. */
    float cf=d->ect_f; if(cf<100)cf=100; if(cf>260)cf=260;
    int ca=(int)(180.0f*(cf-100.0f)/160.0f); lv_arc_set_bg_angles(drv_cool_arc,0,ca);
    lv_obj_set_style_arc_color(drv_cool_arc,lv_color_hex(cf>=235?COL_RED:(cf>=220?COL_YELLOW:0x16BFFF)),LV_PART_MAIN);
    float vv=d->volts; if(vv<10)vv=10; if(vv>16)vv=16;
    int va=(int)(180.0f*(vv-10.0f)/6.0f); lv_arc_set_bg_angles(drv_volt_arc,0,va);
    lv_obj_set_style_arc_color(drv_volt_arc,lv_color_hex((vv<11.5f||vv>15.2f)?COL_RED:COL_GREEN),LV_PART_MAIN);
    for(int g=0;g<4;g++){
        bool active=d->gear_valid && d->gear==(g+1);
        lv_obj_set_style_border_width(drv_gear_box[g],active?4:2,0);
        lv_obj_set_style_border_color(drv_gear_box[g],lv_color_hex(active?0x16CFFF:0x0E6FAF),0);
        lv_obj_set_style_shadow_width(drv_gear_box[g],active?18:0,0);
        lv_obj_set_style_shadow_color(drv_gear_box[g],lv_color_hex(0x16CFFF),0);
        lv_obj_set_style_shadow_opa(drv_gear_box[g],active?LV_OPA_60:LV_OPA_TRANSP,0);
    }
    /* Page 2 remains capability-driven from the vehicle PID map. */
    update_dynamic_live_pages(d);

    const char *status;
    if (!strcmp(d->state, "LIVE")) status = "Connected";
    else if (!strcmp(d->state, "UDS_READY")) status = "UDS ready";
    else if (!strcmp(d->state, "SEARCHING")) status = "Searching...";
    else if (!strcmp(d->state, "ADAPTER_READY")) status = "Adapter ready";
    else status = "Offline";
    snprintf(b, sizeof(b), "%s  |  %s  |  MIL %s", status, d->protocol, d->mil_on ? "ON" : "OFF");
    text_if(l1_status, b);
    lv_obj_set_style_text_color(l1_status, lv_color_hex(d->mil_on ? COL_MIL_ON : COL_MIL_OFF), 0);

    /* page 3 - codes */
    snprintf(b, sizeof(b), "%s  |  %s  |  MIL %s", status, d->protocol, d->mil_on ? "ON" : "OFF");
    text_if(l3_status, b);
    lv_obj_set_style_text_color(l3_status, lv_color_hex(d->mil_on ? COL_MIL_ON : COL_MIL_OFF), 0);
    snprintf(b, sizeof(b), "DTC COUNT: %d", d->dtc_count); text_if(l3_dtccount, b);
    static char dtc_detail[1536];
    format_dtc_details(d->dtc_codes, dtc_detail, sizeof(dtc_detail));
    text_if(l3_dtcs, dtc_detail);

    /* page 5 - adaptive adapter/OEM capabilities */
    snprintf(b, sizeof(b), "ADAPTER: %s", d->adapter_name); text_if(l5_adapter, b);
    char caps[96] = "CAPS:";
    if (d->adapter_caps & OBD_CAP_STANDARD) strncat(caps, " OBD-II", sizeof(caps)-strlen(caps)-1);
    if (d->adapter_caps & OBD_CAP_HS_CAN) strncat(caps, " HS-CAN", sizeof(caps)-strlen(caps)-1);
    if (d->adapter_caps & OBD_CAP_MS_CAN) strncat(caps, " MS-CAN", sizeof(caps)-strlen(caps)-1);
    if (d->adapter_caps & OBD_CAP_SW_CAN) strncat(caps, " SW-CAN", sizeof(caps)-strlen(caps)-1);
    if (d->adapter_caps & OBD_CAP_USB) strncat(caps, " USB", sizeof(caps)-strlen(caps)-1);
    if (d->adapter_caps & OBD_CAP_BT) strncat(caps, " BT", sizeof(caps)-strlen(caps)-1);
    if (d->adapter_caps & OBD_CAP_VPW) strncat(caps, " VPW", sizeof(caps)-strlen(caps)-1);
    if (d->adapter_caps & OBD_CAP_DVI) strncat(caps, " DVI", sizeof(caps)-strlen(caps)-1);
    text_if(l5_caps, caps);
    if (d->vin[0] && strcmp(d->vin, "-") != 0) snprintf(b, sizeof(b), "PROFILE: %s | VIN: %s", d->oem_profile, d->vin);
    else snprintf(b, sizeof(b), "PROFILE: %s", d->oem_profile);
    text_if(l5_profile, b);
    snprintf(b, sizeof(b), "STATUS: %s", d->oem_status); text_if(l5_status, b);
    text_if(l5_result, d->oem_result);
}

static void ui_task(void *arg)
{
    (void)arg;
    obd_data_t d;
    uint32_t last = 0;
    TickType_t last_log_view = 0;
    while (1) {
        obd_auto_snapshot(&d);
        bool need_log_refresh = (page_now == 3) && ((xTaskGetTickCount() - last_log_view) >= pdMS_TO_TICKS(1000));
        bool clear_confirm_expired = s_clear_confirm_deadline_us > 0 && esp_timer_get_time() > s_clear_confirm_deadline_us;
        if (d.seq != last || need_log_refresh || clear_confirm_expired) {
            if (bsp_display_lock(100)) {
                if (d.seq != last) {
                    update_ui(&d);
                    last = d.seq;
                }
                if (clear_confirm_expired) {
                    s_clear_confirm_deadline_us = 0;
                    if (l3_clear_label) lv_label_set_text(l3_clear_label, "RESET CODES");
                }
                if (need_log_refresh) {
                    log_refresh_view();
                    last_log_view = xTaskGetTickCount();
                }
                bsp_display_unlock();
            }
        }
        vTaskDelay(pdMS_TO_TICKS(40));
    }
}


static const lv_image_dsc_t splash_dsc = {
    .header = {.magic=LV_IMAGE_HEADER_MAGIC,.cf=LV_COLOR_FORMAT_RGB565,.flags=0,.w=1024,.h=600,.stride=2048},
    .data_size = 1024*600*2,
    .data = splash_rgb565_start,
};
static void splash_done_cb(lv_timer_t *t)
{
    (void)t;
    if(pages[0]){lv_screen_load_anim(pages[0],LV_SCR_LOAD_ANIM_FADE_IN,300,0,false);page_now=0;}
}
static void build_splash(void)
{
    splash_screen=lv_obj_create(NULL);lv_obj_remove_style_all(splash_screen);
    lv_obj_set_style_bg_color(splash_screen,lv_color_hex(0x01050A),0);lv_obj_set_style_bg_opa(splash_screen,LV_OPA_COVER,0);
    lv_obj_t *im=lv_image_create(splash_screen);lv_image_set_src(im,&splash_dsc);lv_obj_set_pos(im,0,0);
}
esp_err_t dashboard_ui_start(void)
{
    ESP_LOGI(TAG, "ESP32-P4-WIFI6-TOUCH-LCD-7B OBD AUTO V3K - card UI rebuild");
    bsp_display_cfg_t cfg = {
        .lv_adapter_cfg = ESP_LV_ADAPTER_DEFAULT_CONFIG(),
        .rotation = ESP_LV_ADAPTER_ROTATE_0,
        .tear_avoid_mode = ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL,
        .touch_flags = {
            .swap_xy = 0,
            .mirror_x = 1,
            .mirror_y = 1,
        },
    };
    ESP_LOGI(TAG, "Touch mapping: X+Y mirrored to match screen coordinates");
    lv_display_t *disp = bsp_display_start_with_config(&cfg);
    if (!disp) return ESP_FAIL;
    if (!bsp_display_lock(-1)) return ESP_FAIL;
    s_ui_boot_us=esp_timer_get_time();
    build_page1();
    build_page2();
    build_page3();
    build_page4();
    build_splash();
    lv_screen_load(splash_screen);
    page_now = 0;
    lv_timer_create(splash_done_cb,3000,NULL)->repeat_count=1;
    bsp_display_unlock();
    bsp_display_backlight_on();
    bsp_display_brightness_set(s_brightness_pct);
    if (xTaskCreatePinnedToCore(ui_task, "dash_ui", 6144, NULL, 8, NULL, 1) != pdPASS) return ESP_ERR_NO_MEM;
    return ESP_OK;
}
