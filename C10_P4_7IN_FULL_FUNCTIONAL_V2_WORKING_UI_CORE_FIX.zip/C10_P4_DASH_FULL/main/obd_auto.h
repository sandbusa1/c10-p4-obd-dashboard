#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"

typedef enum {
    OBD_OEM_NONE = 0,
    OBD_OEM_FORD,
    OBD_OEM_GM,
    OBD_OEM_CHRYSLER_JEEP,
    OBD_OEM_BMW,
    OBD_OEM_LAND_ROVER
} obd_oem_profile_t;

enum {
    OBD_CAP_STANDARD = 1u << 0,
    OBD_CAP_MS_CAN   = 1u << 1,
    OBD_CAP_SW_CAN   = 1u << 2,
    OBD_CAP_USB      = 1u << 3,
    OBD_CAP_BT       = 1u << 4,
    OBD_CAP_VPW      = 1u << 5,
    OBD_CAP_DVI      = 1u << 6,
    OBD_CAP_HS_CAN   = 1u << 7
};

typedef struct {
    uint32_t seq;
    char state[24];
    char protocol[24];
    char vin[18];
    bool uds_detected;
    int rpm;
    float mph, tps, load, ect_f, iat_f, map_kpa, maf_gps, volts, timing_deg, fuel_pct, afr;
    float stft1, ltft1, stft2, ltft2;
    uint32_t runtime_s;
    /* Vehicle-reported Mode 01 PID bitmaps: 01-20 through A1-C0. */
    uint32_t pid_support[6];
    /* Set only after a PID has returned a valid decoded response this session. */
    uint32_t pid_valid[6];
    float fuel_pressure_kpa;
    float fuel_rail_kpa;
    float fuel_rail_abs_kpa;
    float baro_kpa;
    float ambient_f;
    float relative_tps;
    float abs_load_pct;
    float throttle_b_pct;
    float throttle_c_pct;
    float pedal_d_pct;
    float pedal_e_pct;
    float pedal_f_pct;
    float rel_accel_pct;
    float cmd_throttle_pct;
    float control_module_v;
    float evap_purge_pct;
    float egr_cmd_pct;
    float egr_error_pct;
    float ethanol_pct;
    float hybrid_battery_pct;
    float catalyst_b1s1_f;
    float catalyst_b2s1_f;
    float catalyst_b1s2_f;
    float catalyst_b2s2_f;
    float evap_vapor_pa;
    float actual_afr;
    float oil_temp_f;
    float injection_timing_deg;
    float fuel_rate_lph;
    float demanded_torque_pct;
    float actual_torque_pct;
    uint32_t reference_torque_nm;
    uint8_t obd_standard;
    uint8_t fuel_type;
    uint32_t mil_time_min;
    uint32_t clear_time_min;
    uint32_t distance_mil_km;
    uint32_t distance_clear_km;
    uint32_t warmups_since_clear;
    int gear;
    bool gear_valid;
    int shifter_range; /* 0 unknown, 1=P, 2=R, 3=N, 4=D */
    bool shifter_range_valid;
    float oil_pressure_psi;
    bool oil_pressure_valid;
    bool mil_on;
    int dtc_count;
    char dtc_codes[320];
    uint32_t good, nodata, errors;
    char adapter_name[40];
    uint32_t adapter_caps;
    char oem_profile[24];
    char oem_status[40];
    char oem_result[256];
} obd_data_t;

esp_err_t obd_auto_start(void);
void obd_auto_snapshot(obd_data_t *out);
void obd_auto_request_dtc_refresh(void);
void obd_auto_request_clear_dtcs(void);
void obd_auto_set_oil_pressure(float psi, bool valid);
void obd_auto_set_oem_profile(obd_oem_profile_t profile);
void obd_auto_request_oem_scan(void);
