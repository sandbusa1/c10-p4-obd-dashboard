#include "ftdi_host.h"
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "usb/usb_host.h"
#include "usb/cdc_acm_host.h"
#include "esp_intr_alloc.h"
#include "esp_log.h"
#include "esp_check.h"

#define FTDI_VID 0x0403
#define FTDI_PID 0x6015
#define OBDX_VX_VID 0x0483
#define OBDX_VX_PID 0x5740
#define EP_IN    0x81
#define EP_OUT   0x02
#define RX_SZ    256

#define ACTION_OPEN  (1U << 0)
#define ACTION_CLOSE (1U << 1)

static const char *TAG = "FTDI_HOST";
static usb_host_client_handle_t s_client;
static usb_device_handle_t s_dev;
static usb_transfer_t *s_rx;
static usb_transfer_t *s_tx;
static SemaphoreHandle_t s_tx_done;
static SemaphoreHandle_t s_ctrl_done;
static SemaphoreHandle_t s_host_ready;
static volatile bool s_ready;
static volatile bool s_rx_inflight;
static volatile bool s_tx_inflight;
static volatile uint32_t s_actions;
static volatile uint8_t s_pending_addr;
static ftdi_rx_cb_t s_rx_cb;
static void *s_rx_ctx;
static volatile uint16_t s_last_vid;
static volatile uint16_t s_last_pid;
static cdc_acm_dev_hdl_t s_cdc_dev;
static volatile bool s_cdc_ready;

typedef enum {
    USB_SERIAL_NONE = 0,
    USB_SERIAL_FTDI_EX,
    USB_SERIAL_CDC_VX,
} usb_serial_transport_t;
static volatile usb_serial_transport_t s_transport;


static bool cdc_rx_cb(const uint8_t *data, size_t data_len, void *arg)
{
    (void)arg;
    if (s_rx_cb && data && data_len) s_rx_cb(data, data_len, s_rx_ctx);
    return true;
}

static void cdc_event_cb(const cdc_acm_host_dev_event_data_t *event, void *user_ctx)
{
    (void)user_ctx;
    if (!event) return;
    if (event->type == CDC_ACM_HOST_DEVICE_DISCONNECTED) {
        s_cdc_ready = false;
        s_ready = false;
        s_cdc_dev = NULL;
        s_transport = USB_SERIAL_NONE;
        ESP_LOGW(TAG, "OBDX Pro VX CDC disconnected");
    } else if (event->type == CDC_ACM_HOST_ERROR) {
        ESP_LOGW(TAG, "OBDX Pro VX CDC error: %d", (int)event->data.error);
    }
}

static esp_err_t open_vx_cdc(void)
{
    const cdc_acm_host_device_config_t cfg = {
        .connection_timeout_ms = 1500,
        .out_buffer_size = 512,
        .in_buffer_size = 512,
        .event_cb = cdc_event_cb,
        .data_cb = cdc_rx_cb,
        .user_arg = NULL,
    };

    esp_err_t err = cdc_acm_host_open(OBDX_VX_VID, OBDX_VX_PID, 0, &cfg, &s_cdc_dev);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "OBDX Pro VX CDC open failed: %s", esp_err_to_name(err));
        s_cdc_dev = NULL;
        return err;
    }

    cdc_acm_line_coding_t lc = {
        .dwDTERate = 115200,
        .bCharFormat = 0,
        .bParityType = 0,
        .bDataBits = 8,
    };
    err = cdc_acm_host_line_coding_set(s_cdc_dev, &lc);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "VX CDC line coding 115200 failed: %s", esp_err_to_name(err));
    }
    (void)cdc_acm_host_set_control_line_state(s_cdc_dev, true, true);

    s_transport = USB_SERIAL_CDC_VX;
    s_cdc_ready = true;
    s_ready = true;
    ESP_LOGI(TAG, "OBDX Pro VX CDC serial ready at 115200 baud (VID=%04X PID=%04X)", OBDX_VX_VID, OBDX_VX_PID);
    return ESP_OK;
}

static void bulk_tx_cb(usb_transfer_t *t)
{
    (void)t;
    s_tx_inflight = false;
    if (s_tx_done) xSemaphoreGive(s_tx_done);
}

static void ctrl_cb(usb_transfer_t *t)
{
    (void)t;
    if (s_ctrl_done) xSemaphoreGive(s_ctrl_done);
}

static void rx_cb(usb_transfer_t *t)
{
    s_rx_inflight = false;
    if (t->status == USB_TRANSFER_STATUS_COMPLETED && t->actual_num_bytes >= 2) {
        /* FTDI prepends two modem-status bytes to each USB packet. */
        if (s_rx_cb) s_rx_cb(t->data_buffer + 2, t->actual_num_bytes - 2, s_rx_ctx);
    }
    if (s_ready) {
        t->num_bytes = RX_SZ;
        if (usb_host_transfer_submit(t) == ESP_OK) s_rx_inflight = true;
    }
}

/* Called only from the USB client task, never from a USB callback. While waiting
   for EP0 completion we keep pumping client events so the completion callback can run. */
static esp_err_t ctrl(uint8_t request, uint16_t value, uint16_t index)
{
    usb_transfer_t *t = NULL;
    esp_err_t err = usb_host_transfer_alloc(sizeof(usb_setup_packet_t), 0, &t);
    if (err != ESP_OK) return err;

    usb_setup_packet_t *s = (usb_setup_packet_t *)t->data_buffer;
    s->bmRequestType = USB_BM_REQUEST_TYPE_DIR_OUT |
                       USB_BM_REQUEST_TYPE_TYPE_VENDOR |
                       USB_BM_REQUEST_TYPE_RECIP_DEVICE;
    s->bRequest = request;
    s->wValue = value;
    s->wIndex = index;
    s->wLength = 0;

    t->num_bytes = sizeof(usb_setup_packet_t);
    t->device_handle = s_dev;
    t->bEndpointAddress = 0;
    t->callback = ctrl_cb;

    (void)xSemaphoreTake(s_ctrl_done, 0);
    err = usb_host_transfer_submit_control(s_client, t);
    if (err == ESP_OK) {
        const TickType_t deadline = xTaskGetTickCount() + pdMS_TO_TICKS(500);
        while (xSemaphoreTake(s_ctrl_done, 0) != pdTRUE) {
            if ((int32_t)(deadline - xTaskGetTickCount()) <= 0) {
                err = ESP_ERR_TIMEOUT;
                break;
            }
            (void)usb_host_client_handle_events(s_client, pdMS_TO_TICKS(20));
        }
    }
    usb_host_transfer_free(t);
    return err;
}

static esp_err_t configure_ftdi(void)
{
    /* Reset SIO, 8-N-1, no flow control, 115200 baud.
       0x001A/0x0001 is the divisor pair previously observed working with
       the OBDLink EX FTDI device 0403:6015. */
    ESP_RETURN_ON_ERROR(ctrl(0, 0, 1), TAG, "reset");
    ESP_RETURN_ON_ERROR(ctrl(4, 8, 1), TAG, "data format");
    ESP_RETURN_ON_ERROR(ctrl(2, 0, 1), TAG, "flow control");
    ESP_RETURN_ON_ERROR(ctrl(3, 0x001A, 0x0001), TAG, "baud");
    return ESP_OK;
}

static void client_event(const usb_host_client_event_msg_t *msg, void *arg)
{
    (void)arg;
    /* ESP-IDF invokes this from usb_host_client_handle_events(); keep it non-blocking. */
    if (msg->event == USB_HOST_CLIENT_EVENT_NEW_DEV && !s_dev) {
        s_pending_addr = msg->new_dev.address;
        s_actions |= ACTION_OPEN;
    } else if (msg->event == USB_HOST_CLIENT_EVENT_DEV_GONE) {
        s_ready = false;
        s_actions |= ACTION_CLOSE;
    }
}

static void free_transfers(void)
{
    if (s_rx) {
        usb_host_transfer_free(s_rx);
        s_rx = NULL;
    }
    if (s_tx) {
        usb_host_transfer_free(s_tx);
        s_tx = NULL;
    }
}

static void close_device(void)
{
    s_ready = false;
    if (s_cdc_dev) {
        cdc_acm_dev_hdl_t h = s_cdc_dev;
        s_cdc_dev = NULL;
        s_cdc_ready = false;
        s_transport = USB_SERIAL_NONE;
        (void)cdc_acm_host_close(h);
        ESP_LOGW(TAG, "OBDX Pro VX CDC closed");
    }
    if (!s_dev) {
        free_transfers();
        return;
    }

    /* Stop and flush queued bulk transfers before releasing the interface. */
    (void)usb_host_endpoint_halt(s_dev, EP_IN);
    (void)usb_host_endpoint_flush(s_dev, EP_IN);
    (void)usb_host_endpoint_halt(s_dev, EP_OUT);
    (void)usb_host_endpoint_flush(s_dev, EP_OUT);

    const TickType_t deadline = xTaskGetTickCount() + pdMS_TO_TICKS(250);
    while ((s_rx_inflight || s_tx_inflight) && (int32_t)(deadline - xTaskGetTickCount()) > 0) {
        (void)usb_host_client_handle_events(s_client, pdMS_TO_TICKS(20));
    }
    s_rx_inflight = false;
    s_tx_inflight = false;

    free_transfers();
    (void)usb_host_interface_release(s_client, s_dev, 0);
    (void)usb_host_device_close(s_client, s_dev);
    s_dev = NULL;
    ESP_LOGW(TAG, "OBDLink EX disconnected");
}

static esp_err_t open_device(uint8_t addr)
{
    esp_err_t err = usb_host_device_open(s_client, addr, &s_dev);
    if (err != ESP_OK) return err;

    const usb_device_desc_t *dd = NULL;
    err = usb_host_get_device_descriptor(s_dev, &dd);
    if (err != ESP_OK || !dd) {
        ESP_LOGW(TAG, "Unable to read USB descriptor at address %u", (unsigned)addr);
        (void)usb_host_device_close(s_client, s_dev);
        s_dev = NULL;
        return ESP_ERR_NOT_SUPPORTED;
    }

    s_last_vid = dd->idVendor;
    s_last_pid = dd->idProduct;
    ESP_LOGI(TAG, "USB probe VID=%04X PID=%04X", dd->idVendor, dd->idProduct);

    if (dd->idVendor == OBDX_VX_VID && dd->idProduct == OBDX_VX_PID) {
        ESP_LOGI(TAG, "OBDX Pro VX detected; selecting CDC-ACM transport");
        (void)usb_host_device_close(s_client, s_dev);
        s_dev = NULL;
        return open_vx_cdc();
    }

    if (dd->idVendor != FTDI_VID || dd->idProduct != FTDI_PID) {
        ESP_LOGW(TAG, "Unsupported USB serial adapter: VID=%04X PID=%04X", dd->idVendor, dd->idProduct);
        (void)usb_host_device_close(s_client, s_dev);
        s_dev = NULL;
        return ESP_ERR_NOT_SUPPORTED;
    }

    ESP_LOGI(TAG, "OBDLink EX detected; selecting FTDI transport");
    ESP_LOGI(TAG, "USB device VID=%04X PID=%04X", dd->idVendor, dd->idProduct);
    err = usb_host_interface_claim(s_client, s_dev, 0, 0);
    if (err != ESP_OK) {
        (void)usb_host_device_close(s_client, s_dev);
        s_dev = NULL;
        return err;
    }

    err = configure_ftdi();
    if (err != ESP_OK) goto fail;

    err = usb_host_transfer_alloc(RX_SZ, 0, &s_rx);
    if (err != ESP_OK) goto fail;
    err = usb_host_transfer_alloc(256, 0, &s_tx);
    if (err != ESP_OK) goto fail;

    s_rx->device_handle = s_dev;
    s_rx->bEndpointAddress = EP_IN;
    s_rx->callback = rx_cb;
    s_rx->num_bytes = RX_SZ;

    s_tx->device_handle = s_dev;
    s_tx->bEndpointAddress = EP_OUT;
    s_tx->callback = bulk_tx_cb;

    s_transport = USB_SERIAL_FTDI_EX;
    s_ready = true;
    err = usb_host_transfer_submit(s_rx);
    if (err != ESP_OK) {
        s_ready = false;
        goto fail;
    }
    s_rx_inflight = true;
    ESP_LOGI(TAG, "OBDLink EX FTDI serial ready at 115200 baud");
    return ESP_OK;

fail:
    s_ready = false;
    free_transfers();
    if (s_dev) {
        (void)usb_host_interface_release(s_client, s_dev, 0);
        (void)usb_host_device_close(s_client, s_dev);
        s_dev = NULL;
    }
    return err;
}

static void usb_lib_task(void *arg)
{
    (void)arg;
    const usb_host_config_t cfg = {
        .skip_phy_setup = false,
        .intr_flags = ESP_INTR_FLAG_LEVEL1,
    };
    esp_err_t err = usb_host_install(&cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "usb_host_install failed: %s", esp_err_to_name(err));
        vTaskDelete(NULL);
        return;
    }
    ESP_LOGI(TAG, "USB Host installed");
    err = cdc_acm_host_install(NULL);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "cdc_acm_host_install failed: %s", esp_err_to_name(err));
        vTaskDelete(NULL);
        return;
    }
    ESP_LOGI(TAG, "CDC-ACM host driver installed for OBDX Pro VX");
    xSemaphoreGive(s_host_ready);

    while (1) {
        uint32_t flags = 0;
        (void)usb_host_lib_handle_events(portMAX_DELAY, &flags);
        if (flags & USB_HOST_LIB_EVENT_FLAGS_NO_CLIENTS) {
            (void)usb_host_device_free_all();
        }
    }
}

static void usb_client_task(void *arg)
{
    (void)arg;
    if (xSemaphoreTake(s_host_ready, pdMS_TO_TICKS(3000)) != pdTRUE) {
        ESP_LOGE(TAG, "USB host library did not start");
        vTaskDelete(NULL);
        return;
    }

    const usb_host_client_config_t ccfg = {
        .is_synchronous = false,
        .max_num_event_msg = 8,
        .async = {
            .client_event_callback = client_event,
            .callback_arg = NULL,
        },
    };

    esp_err_t err = usb_host_client_register(&ccfg, &s_client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "usb_host_client_register failed: %s", esp_err_to_name(err));
        vTaskDelete(NULL);
        return;
    }

    while (1) {
        (void)usb_host_client_handle_events(s_client, pdMS_TO_TICKS(50));
        uint32_t actions = s_actions;
        if (actions & ACTION_CLOSE) {
            s_actions &= ~ACTION_CLOSE;
            close_device();
        }
        if ((actions & ACTION_OPEN) && !s_dev) {
            s_actions &= ~ACTION_OPEN;
            err = open_device(s_pending_addr);
            if (err != ESP_OK && err != ESP_ERR_NOT_SUPPORTED) {
                ESP_LOGW(TAG, "OBDLink EX open/config failed: %s", esp_err_to_name(err));
            }
        }
    }
}

esp_err_t ftdi_host_start(ftdi_rx_cb_t cb, void *ctx)
{
    s_rx_cb = cb;
    s_rx_ctx = ctx;
    s_tx_done = xSemaphoreCreateBinary();
    s_ctrl_done = xSemaphoreCreateBinary();
    s_host_ready = xSemaphoreCreateBinary();
    if (!s_tx_done || !s_ctrl_done || !s_host_ready) return ESP_ERR_NO_MEM;

    if (xTaskCreatePinnedToCore(usb_lib_task, "usb_lib", 4096, NULL, 20, NULL, 0) != pdPASS) {
        return ESP_ERR_NO_MEM;
    }
    if (xTaskCreatePinnedToCore(usb_client_task, "usb_client", 6144, NULL, 19, NULL, 0) != pdPASS) {
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}

bool ftdi_host_ready(void)
{
    return s_ready;
}

esp_err_t ftdi_host_write(const uint8_t *data, size_t len, uint32_t timeout_ms)
{
    if (!s_ready || !data || !len) return ESP_ERR_INVALID_STATE;
    if (s_transport == USB_SERIAL_CDC_VX) {
        if (!s_cdc_ready || !s_cdc_dev) return ESP_ERR_INVALID_STATE;
        return cdc_acm_host_data_tx_blocking(s_cdc_dev, data, len, timeout_ms);
    }
    if (s_transport != USB_SERIAL_FTDI_EX || !s_tx || len > 256) return ESP_ERR_INVALID_STATE;
    if (s_tx_inflight) return ESP_ERR_INVALID_STATE;

    memcpy(s_tx->data_buffer, data, len);
    s_tx->num_bytes = len;
    (void)xSemaphoreTake(s_tx_done, 0);
    s_tx_inflight = true;
    esp_err_t err = usb_host_transfer_submit(s_tx);
    if (err != ESP_OK) {
        s_tx_inflight = false;
        return err;
    }
    if (xSemaphoreTake(s_tx_done, pdMS_TO_TICKS(timeout_ms)) != pdTRUE) {
        return ESP_ERR_TIMEOUT;
    }
    return ESP_OK;
}

void ftdi_host_last_usb_id(uint16_t *vid, uint16_t *pid)
{
    if (vid) *vid = s_last_vid;
    if (pid) *pid = s_last_pid;
}
