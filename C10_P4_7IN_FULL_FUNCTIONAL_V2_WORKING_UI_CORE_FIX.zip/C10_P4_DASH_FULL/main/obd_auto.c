#include "obd_auto.h"
#include "ftdi_host.h"
#include "sd_logger.h"
#include <ctype.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_timer.h"
#include "nvs.h"

static const char *TAG="OBDLINK_ALL";
static SemaphoreHandle_t s_lock;
static SemaphoreHandle_t s_resp_sem;
static volatile bool s_diag_busy = false;
static obd_data_t s_d;
static char s_rx[1024];
static size_t s_rxn;
static volatile bool s_refresh_dtcs, s_clear_dtcs;
static volatile bool s_oem_scan;
static volatile obd_oem_profile_t s_oem_profile = OBD_OEM_NONE;
static uint8_t s_cached_proto;
static char s_cached_vin[18];
static bool s_uds_only;

/* OEM diagnostic scratch buffers live in static storage rather than on the
 * OBD task stack.  Ford scans call the generic DTC reader from inside the OEM
 * scan path, so keeping these buffers off-stack removes the deepest stack
 * spike seen at the exact point of the previous intermittent resets. */
static char s_oem_rx[512];
static char s_oem_result_buf[320];
static char s_oem_vin_buf[320];

static int hexbytes(const char *s, uint8_t *b, int cap);

static void load_vehicle_profile_cache(void)
{
    nvs_handle_t h;
    s_cached_proto = 0;
    s_cached_vin[0] = 0;
    if (nvs_open("obdprof", NVS_READONLY, &h) != ESP_OK) return;
    (void)nvs_get_u8(h, "proto", &s_cached_proto);
    size_t n = sizeof(s_cached_vin);
    if (nvs_get_str(h, "vin", s_cached_vin, &n) != ESP_OK) s_cached_vin[0] = 0;
    nvs_close(h);
    if (s_cached_proto >= 1 && s_cached_proto <= 9)
        ESP_LOGI(TAG, "Cached vehicle profile: protocol=%u VIN=%s", (unsigned)s_cached_proto, s_cached_vin[0] ? s_cached_vin : "unknown");
}

static void save_vehicle_profile(uint8_t proto, const char *vin)
{
    nvs_handle_t h;
    if (nvs_open("obdprof", NVS_READWRITE, &h) != ESP_OK) return;
    if (proto >= 1 && proto <= 9) {
        (void)nvs_set_u8(h, "proto", proto);
        s_cached_proto = proto;
    }
    if (vin && strlen(vin) == 17) {
        (void)nvs_set_str(h, "vin", vin);
        snprintf(s_cached_vin, sizeof(s_cached_vin), "%s", vin);
    }
    (void)nvs_commit(h);
    nvs_close(h);
}

static uint8_t parse_atdpn_protocol(const char *r)
{
    if (!r) return 0;
    /* ATDPN commonly returns 6 or A6 (A = selected automatically). */
    for (const char *p = r; *p; ++p) {
        if (*p >= '1' && *p <= '9') return (uint8_t)(*p - '0');
    }
    return 0;
}

static bool extract_vin_ascii(const char *resp, char vin[18])
{
    uint8_t b[256];
    int n = hexbytes(resp, b, sizeof(b));
    int start = -1;
    for (int i = 0; i + 2 < n; ++i) {
        if (b[i] == 0x49 && b[i + 1] == 0x02) { start = i + 2; break; }
        if (b[i] == 0x62 && b[i + 1] == 0xF1 && b[i + 2] == 0x90) { start = i + 3; break; }
    }
    if (start < 0) return false;
    int w = 0;
    for (int i = start; i < n && w < 17; ++i) {
        unsigned char c = b[i];
        if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'H') ||
            (c >= 'J' && c <= 'N') || (c >= 'P' && c <= 'R') ||
            (c >= 'S' && c <= 'Z')) vin[w++] = (char)c;
    }
    vin[w] = 0;
    return w == 17;
}

static bool response_has_seq(const char *resp, const uint8_t *seq, size_t seqn)
{
    uint8_t b[256]; int n = hexbytes(resp, b, sizeof(b));
    if (!resp || !seq || !seqn) return false;
    for (int i = 0; i + (int)seqn <= n; ++i)
        if (memcmp(&b[i], seq, seqn) == 0) return true;
    return false;
}

static void rx_bytes(const uint8_t *p, size_t n, void *ctx)
{
    (void)ctx;
    for (size_t i=0;i<n;i++) {
        char c=(char)p[i];
        if (s_rxn < sizeof(s_rx)-1) s_rx[s_rxn++]=c;
        if (c=='>') {
            s_rx[s_rxn]=0;
            xSemaphoreGive(s_resp_sem);
        }
    }
}

static void set_state(const char *st)
{
    bool changed = false;
    char previous[24];
    xSemaphoreTake(s_lock, portMAX_DELAY);
    snprintf(previous, sizeof(previous), "%s", s_d.state);
    if (strcmp(s_d.state, st) != 0) changed = true;
    snprintf(s_d.state,sizeof(s_d.state),"%s",st);
    s_d.seq++;
    xSemaphoreGive(s_lock);
    if (changed) sd_logger_event("STATE", "%s -> %s", previous, st);
}

static bool elm_cmd(const char *cmd, char *out, size_t out_sz, uint32_t timeout_ms)
{
    if (!ftdi_host_ready()) return false;
    s_rxn=0; s_rx[0]=0; xSemaphoreTake(s_resp_sem,0);
    char line[40]; snprintf(line,sizeof(line),"%s\r",cmd);
    if (ftdi_host_write((const uint8_t*)line,strlen(line),500)!=ESP_OK) return false;
    if (xSemaphoreTake(s_resp_sem,pdMS_TO_TICKS(timeout_ms))!=pdTRUE) return false;
    if (out && out_sz) { snprintf(out,out_sz,"%s",s_rx); }
    return true;
}


static const char *oem_name(obd_oem_profile_t p)
{
    switch (p) {
        case OBD_OEM_FORD: return "FORD";
        case OBD_OEM_GM: return "GM";
        case OBD_OEM_CHRYSLER_JEEP: return "CHRYSLER/JEEP";
        case OBD_OEM_BMW: return "BMW";
        case OBD_OEM_LAND_ROVER: return "LAND ROVER";
        default: return "NONE";
    }
}

static void detect_adapter(void)
{
    char ati[160] = "", sti[160] = "";
    uint16_t vid = 0, pid = 0;
    ftdi_host_last_usb_id(&vid, &pid);
    (void)elm_cmd("ATI", ati, sizeof(ati), 1200);
    (void)elm_cmd("STI", sti, sizeof(sti), 1200);

    /* USB identity is authoritative for adapters we have physically tested.
       OBDX Pro VX reports a generic ELM327 identity in ELM mode, so relying on
       ATI/STI alone incorrectly classified it as an OBDLink EX. */
    const bool usb_vx = (vid == 0x0483 && pid == 0x5740);
    const bool usb_ex = (vid == 0x0403 && pid == 0x6015);
    bool is_obdx = usb_vx || strstr(ati, "OBDX") || strstr(ati, "obdx") || strstr(sti, "OBDX") || strstr(sti, "obdx");
    bool is_vx = usb_vx || (is_obdx && (strstr(ati, "VX") || strstr(ati, "vx") || strstr(sti, "VX") || strstr(sti, "vx")));
    bool is_ft = !usb_vx && is_obdx && (strstr(ati, "FT") || strstr(ati, "ft") || strstr(sti, "FT") || strstr(sti, "ft"));
    bool is_gt = !usb_vx && is_obdx && (strstr(ati, "GT") || strstr(ati, "gt") || strstr(sti, "GT") || strstr(sti, "gt"));

    xSemaphoreTake(s_lock, portMAX_DELAY);
    if (is_vx) {
        snprintf(s_d.adapter_name, sizeof(s_d.adapter_name), "OBDX Pro VX");
        s_d.adapter_caps = OBD_CAP_STANDARD | OBD_CAP_HS_CAN | OBD_CAP_USB | OBD_CAP_VPW | OBD_CAP_DVI;
        snprintf(s_d.oem_status, sizeof(s_d.oem_status), "VX: HS-CAN + VPW (MS/SW skipped)");
    } else if (is_ft) {
        snprintf(s_d.adapter_name, sizeof(s_d.adapter_name), "OBDX Pro FT");
        s_d.adapter_caps = OBD_CAP_STANDARD | OBD_CAP_HS_CAN | OBD_CAP_MS_CAN | OBD_CAP_USB | OBD_CAP_DVI;
        snprintf(s_d.oem_status, sizeof(s_d.oem_status), "FT: HS-CAN + FORD MS-CAN");
    } else if (is_gt) {
        snprintf(s_d.adapter_name, sizeof(s_d.adapter_name), "OBDX Pro GT");
        s_d.adapter_caps = OBD_CAP_STANDARD | OBD_CAP_HS_CAN | OBD_CAP_SW_CAN | OBD_CAP_USB | OBD_CAP_VPW | OBD_CAP_DVI;
        snprintf(s_d.oem_status, sizeof(s_d.oem_status), "GT: HS-CAN + GM SW-CAN + VPW");
    } else if (is_obdx) {
        snprintf(s_d.adapter_name, sizeof(s_d.adapter_name), "OBDX Pro (unknown model)");
        s_d.adapter_caps = OBD_CAP_STANDARD | OBD_CAP_HS_CAN | OBD_CAP_USB | OBD_CAP_DVI;
        snprintf(s_d.oem_status, sizeof(s_d.oem_status), "OBDX: HS-CAN; model buses unknown");
    } else {
        snprintf(s_d.adapter_name, sizeof(s_d.adapter_name), "OBDLink EX / USB");
        s_d.adapter_caps = OBD_CAP_STANDARD | OBD_CAP_HS_CAN | OBD_CAP_MS_CAN | OBD_CAP_USB | OBD_CAP_VPW;
        snprintf(s_d.oem_status, sizeof(s_d.oem_status), "EX: HS-CAN + FORD MS-CAN + legacy OBD");
    }
    s_d.seq++;
    xSemaphoreGive(s_lock);
    sd_logger_event("ADAPTER", "USB=%04X:%04X ATI=%.60s STI=%.60s auto=%s",
                    vid, pid, ati, sti,
                    is_vx ? "OBDX_VX" : (usb_ex ? "OBDLINK_EX" : (is_obdx ? "OBDX" : "GENERIC_ELM")));
}

static void set_oem_result(const char *status, const char *result)
{
    xSemaphoreTake(s_lock, portMAX_DELAY);
    snprintf(s_d.oem_profile, sizeof(s_d.oem_profile), "%s", oem_name(s_oem_profile));
    snprintf(s_d.oem_status, sizeof(s_d.oem_status), "%s", status ? status : "-");
    snprintf(s_d.oem_result, sizeof(s_d.oem_result), "%s", result ? result : "-");
    s_d.seq++;
    xSemaphoreGive(s_lock);
}

static void refresh_dtcs(void);

static uint32_t adapter_caps_now(void)
{
    uint32_t caps = 0;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    caps = s_d.adapter_caps;
    xSemaphoreGive(s_lock);
    return caps;
}

static bool probe_hs_can(char *detail, size_t detail_sz)
{
    char r[256] = "";
    bool ok = elm_cmd("ATSP6", r, sizeof(r), 1500) &&
              elm_cmd("ATSH7DF", r, sizeof(r), 1200) &&
              elm_cmd("0100", r, sizeof(r), 2500) &&
              !strstr(r, "NO DATA") && !strstr(r, "UNABLE") && !strstr(r, "BUS ERROR");
    if (detail && detail_sz) snprintf(detail, detail_sz, "HS-CAN 11/500 PCM=%s", ok ? "CONNECTED" : "NO RESPONSE");
    return ok;
}

static void run_oem_readonly_scan(void)
{
    obd_oem_profile_t p = s_oem_profile;
    char *r = s_oem_rx;
    char *result = s_oem_result_buf;
    r[0] = 0;
    result[0] = 0;
    set_oem_result("SCANNING...", "Read-only adapter / vehicle capability probe");
    sd_logger_event("OEM", "read-only scan start profile=%s", oem_name(p));

    if (p == OBD_OEM_NONE) {
        set_oem_result("SELECT PROFILE", "Choose Ford, GM, Chrysler/Jeep, BMW, or Land Rover");
        s_diag_busy = false;
        return;
    }

    uint32_t caps = adapter_caps_now();
    if (p == OBD_OEM_FORD) {
        char hs[64] = "";
        bool hs_ok = (caps & OBD_CAP_HS_CAN) ? probe_hs_can(hs, sizeof(hs)) : false;
        bool ms_switch = false;
        if (caps & OBD_CAP_MS_CAN) {
            /* OBDLink EX/OBDX FT class hardware can physically route Ford MS-CAN.
               STP53 is the OBDLink ISO15765 11-bit/125k MS-CAN preset.  A
               successful switch proves adapter capability; individual module
               discovery still needs Ford-specific addresses/services. */
            ms_switch = elm_cmd("STP53", r, sizeof(s_oem_rx), 1500) && !strstr(r, "?") && !strstr(r, "ERROR");
        }
        snprintf(result, sizeof(s_oem_result_buf),
                 "Ford buses: %s. MS-CAN: %s. Powertrain/MIL/DTC scan uses HS-CAN; body/cluster modules require OEM addressing.",
                 hs[0] ? hs : (hs_ok ? "HS-CAN CONNECTED" : "HS-CAN UNAVAILABLE"),
                 (caps & OBD_CAP_MS_CAN) ? (ms_switch ? "ADAPTER READY" : "SWITCH FAILED") : "SKIPPED (adapter unsupported)");
    } else if (p == OBD_OEM_GM) {
        char hs[64] = "";
        (void)((caps & OBD_CAP_HS_CAN) && probe_hs_can(hs, sizeof(hs)));
        snprintf(result, sizeof(s_oem_result_buf),
                 "GM buses: %s. GMLAN/SW-CAN: %s. VPW: %s. Low-speed module scan is skipped unless the adapter has a SW-CAN transceiver.",
                 hs[0] ? hs : "HS-CAN unavailable",
                 (caps & OBD_CAP_SW_CAN) ? "ADAPTER CAPABLE (OEM/DVI module addressing required)" : "SKIPPED (adapter unsupported)",
                 (caps & OBD_CAP_VPW) ? "AVAILABLE" : "UNAVAILABLE");
    } else if (p == OBD_OEM_CHRYSLER_JEEP) {
        char hs[64] = "";
        (void)((caps & OBD_CAP_HS_CAN) && probe_hs_can(hs, sizeof(hs)));
        snprintf(result, sizeof(s_oem_result_buf), "Chrysler/Jeep: %s. Additional body networks/security gateways require platform-specific definitions.", hs[0] ? hs : "HS-CAN unavailable");
    } else if (p == OBD_OEM_BMW) {
        char hs[64] = "";
        (void)((caps & OBD_CAP_HS_CAN) && probe_hs_can(hs, sizeof(hs)));
        snprintf(result, sizeof(s_oem_result_buf), "BMW: %s. K-CAN/DoIP and OEM modules require model-specific transport/definitions.", hs[0] ? hs : "HS-CAN unavailable");
    } else if (p == OBD_OEM_LAND_ROVER) {
        char hs[64] = "";
        (void)((caps & OBD_CAP_HS_CAN) && probe_hs_can(hs, sizeof(hs)));
        snprintf(result, sizeof(s_oem_result_buf), "Land Rover/Range Rover: %s. Secondary CAN/module coverage varies by platform and adapter hardware.", hs[0] ? hs : "HS-CAN unavailable");
    }

    /* Read standard VIN when available; it is safe and read-only. */
    char *vin = s_oem_vin_buf;
    vin[0] = 0;
    if (elm_cmd("0902", vin, sizeof(s_oem_vin_buf), 2000) && !strstr(vin, "NO DATA")) {
        size_t used = strlen(result);
        if (used < sizeof(s_oem_result_buf) - 12) snprintf(result + used, sizeof(s_oem_result_buf) - used, " VIN response received.");
    }

    /* A Ford OEM scan should also populate the real DTC page.  Previously this
       page only displayed the informational "Powertrain DTCs use HS-CAN"
       message and did not actually run the DTC reader. */
    if (p == OBD_OEM_FORD) {
        sd_logger_event("OEM", "Ford scan: reading stored/pending/permanent DTCs on HS-CAN");
        refresh_dtcs();
        /* Make the OEM scan page explicitly report that codes were found.
           The detailed list remains on Page 3, but Page 5 no longer looks
           like a successful scan returned nothing. */
        int dtc_count = 0;
        xSemaphoreTake(s_lock, portMAX_DELAY);
        dtc_count = s_d.dtc_count;
        xSemaphoreGive(s_lock);
        size_t used = strlen(result);
        if (used < sizeof(s_oem_result_buf) - 32) {
            if (dtc_count > 0) {
                snprintf(result + used, sizeof(s_oem_result_buf) - used,
                         " DTCs FOUND: %d - see Page 3.", dtc_count);
            } else {
                snprintf(result + used, sizeof(s_oem_result_buf) - used,
                         " No standard emissions DTCs decoded.");
            }
        }
    }

    /* Restore automatic protocol selection after any adapter protocol probe. */
    (void)elm_cmd("ATSP0", r, sizeof(s_oem_rx), 1200);
    set_oem_result("COMPLETE - READ ONLY", result);
    sd_logger_event("OEM", "profile=%s result=%s", oem_name(p), result);
    s_diag_busy = false;
}

static int hexbytes(const char *s, uint8_t *b, int cap)
{
    int n=0, hi=-1;
    for (; *s && n<cap; s++) {
        if (!isxdigit((unsigned char)*s)) { hi=-1; continue; }
        int v = isdigit((unsigned char)*s)?*s-'0':(toupper((unsigned char)*s)-'A'+10);
        if (hi<0) hi=v; else { b[n++]=(uint8_t)((hi<<4)|v); hi=-1; }
    }
    return n;
}

static bool pid_bytes(const char *resp, uint8_t pid, uint8_t *payload, int need)
{
    uint8_t b[128]; int n=hexbytes(resp,b,sizeof(b));
    for(int i=0;i+2+need<=n;i++) if(b[i]==0x41 && b[i+1]==pid) { memcpy(payload,&b[i+2],need); return true; }
    return false;
}

static bool qpid(const char *cmd, uint8_t pid, uint8_t *p, int need, uint32_t to)
{
    char r[512];
    if(!elm_cmd(cmd,r,sizeof(r),to)) return false;
    if(strstr(r,"NO DATA")||strstr(r,"BUS ERROR")||strstr(r,"UNABLE")) {
        xSemaphoreTake(s_lock,portMAX_DELAY); s_d.nodata++; s_d.seq++; xSemaphoreGive(s_lock);
        return false;
    }
    if(!pid_bytes(r,pid,p,need)) {
        xSemaphoreTake(s_lock,portMAX_DELAY); s_d.errors++; s_d.seq++; xSemaphoreGive(s_lock);
        return false;
    }
    xSemaphoreTake(s_lock,portMAX_DELAY);
    s_d.good++;
    if (pid >= 1 && pid <= 0xC0) {
        unsigned block = (pid - 1u) / 32u;
        unsigned offset = (pid - 1u) % 32u;
        if (block < 6) s_d.pid_valid[block] |= (1u << (31u - offset));
    }
    xSemaphoreGive(s_lock);
    return true;
}

static bool pid_is_supported(uint8_t pid)
{
    bool yes = false;
    if (pid == 0 || pid > 0xC0) return false;
    unsigned block = (pid - 1u) / 32u;
    unsigned offset = (pid - 1u) % 32u;
    if (block >= 6) return false;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    yes = (s_d.pid_support[block] & (1u << (31u - offset))) != 0;
    xSemaphoreGive(s_lock);
    return yes;
}

static uint32_t pid_bitmap_word(const uint8_t p[4])
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

static void discover_supported_pids(void)
{
    uint8_t p[4] = {0};
    uint32_t bm[6] = {0,0,0,0,0,0};
    xSemaphoreTake(s_lock, portMAX_DELAY);
    memset(s_d.pid_support, 0, sizeof(s_d.pid_support));
    memset(s_d.pid_valid, 0, sizeof(s_d.pid_valid));
    xSemaphoreGive(s_lock);
    /* Walk the SAE continuation chain instead of stopping at PID 60.  Each
       bitmap's LSB advertises the next 32-PID block (20/40/60/80/A0/C0). */
    for (unsigned block = 0; block < 6; ++block) {
        if (block > 0 && (bm[block - 1] & 1u) == 0) break;
        uint8_t base = (uint8_t)(block * 0x20u);
        char cmd[8];
        snprintf(cmd, sizeof(cmd), "01%02X", base);
        if (!qpid(cmd, base, p, 4, 1800)) break;
        bm[block] = pid_bitmap_word(p);
    }
    xSemaphoreTake(s_lock, portMAX_DELAY);
    memcpy(s_d.pid_support, bm, sizeof(bm));
    s_d.seq++;
    xSemaphoreGive(s_lock);
    sd_logger_event("PIDMAP",
                    "01-20=%08" PRIX32 " 21-40=%08" PRIX32 " 41-60=%08" PRIX32
                    " 61-80=%08" PRIX32 " 81-A0=%08" PRIX32 " A1-C0=%08" PRIX32,
                    bm[0], bm[1], bm[2], bm[3], bm[4], bm[5]);

    /* Read low-frequency encoded/static identifiers once after discovery. */
    if (pid_is_supported(0x1C) && qpid("011C", 0x1C, p, 1, 900)) {
        xSemaphoreTake(s_lock, portMAX_DELAY); s_d.obd_standard = p[0]; xSemaphoreGive(s_lock);
    }
    if (pid_is_supported(0x51) && qpid("0151", 0x51, p, 1, 900)) {
        xSemaphoreTake(s_lock, portMAX_DELAY); s_d.fuel_type = p[0]; xSemaphoreGive(s_lock);
    }
}

static bool test_protocol(void)
{
    /* PID 00 is the supported-PID bitmap and is a better connection probe than
       RPM: it works with key-on/engine-off and is required for normal OBD-II
       discovery.  Log the raw probe so a failed vehicle connection is visible
       on the serial monitor instead of looking like a blank dashboard. */
    char r[512] = "";
    uint8_t p[4];
    if (!elm_cmd("0100", r, sizeof(r), 10000)) {
        ESP_LOGW(TAG, "0100 -> timeout/no ELM prompt");
        return false;
    }
    ESP_LOGI(TAG, "0100 -> %.180s", r);
    if (strstr(r, "NO DATA") || strstr(r, "BUS ERROR") || strstr(r, "UNABLE") || strstr(r, "STOPPED")) {
        return false;
    }
    if (!pid_bytes(r, 0x00, p, 4)) {
        ESP_LOGW(TAG, "0100 response did not contain a valid 41 00 PID bitmap");
        return false;
    }
    return true;
}

static void set_protocol_name(const char *name)
{
    xSemaphoreTake(s_lock, portMAX_DELAY);
    snprintf(s_d.protocol, sizeof(s_d.protocol), "%s", name ? name : "-");
    s_d.seq++;
    xSemaphoreGive(s_lock);
}


static bool protocol_supported_by_adapter(uint8_t proto, bool is_vx)
{
    if (proto < 1 || proto > 9) return false;
    if (!is_vx) return true;
    return proto == 2 || proto == 6 || proto == 7 || proto == 8 || proto == 9;
}

static bool apply_functional_header(uint8_t proto, bool is_vx)
{
    char r[128] = "";
    const char *h = NULL;
    if (proto == 2 && is_vx) h = "ATSH6C10F1";
    else if (proto == 6 || proto == 8) h = "ATSH7DF";
    else if (proto == 7 || proto == 9) h = "ATSH18DB33F1";
    if (!h) return true;
    if (!elm_cmd(h, r, sizeof(r), 1200)) return false;
    return strstr(r, "?") == NULL && strstr(r, "ERROR") == NULL;
}

static bool probe_uds_vin_on_current_can(char *vin_out, size_t vin_out_sz)
{
    char r[768] = "";
    static const uint8_t positive[] = {0x62, 0xF1, 0x90};
    if (!elm_cmd("22F190", r, sizeof(r), 2500)) return false;
    ESP_LOGI(TAG, "UDS VIN probe 22F190 -> %.220s", r);
    if (!response_has_seq(r, positive, sizeof(positive))) return false;
    char vin[18] = "";
    if (extract_vin_ascii(r, vin)) {
        if (vin_out && vin_out_sz) snprintf(vin_out, vin_out_sz, "%s", vin);
        save_vehicle_profile(0, vin);
    }
    return true;
}

static bool try_cached_protocol(bool is_vx)
{
    if (!protocol_supported_by_adapter(s_cached_proto, is_vx)) return false;
    char r[128] = "";
    char cmd[8];
    snprintf(cmd, sizeof(cmd), "ATSP%u", (unsigned)s_cached_proto);
    ESP_LOGI(TAG, "Fast start: trying cached protocol %u first", (unsigned)s_cached_proto);
    if (!elm_cmd(cmd, r, sizeof(r), 1600)) return false;
    if (strstr(r, "?") || strstr(r, "ERROR")) return false;
    if (!apply_functional_header(s_cached_proto, is_vx)) return false;
    if (!test_protocol()) {
        ESP_LOGW(TAG, "Cached protocol %u did not answer; falling back to discovery", (unsigned)s_cached_proto);
        return false;
    }
    char name[24];
    snprintf(name, sizeof(name), "CACHED P%u", (unsigned)s_cached_proto);
    set_protocol_name(name);
    sd_logger_event("OBD", "fast-start cached protocol=%u", (unsigned)s_cached_proto);
    return true;
}

static bool select_protocol(void)
{
    char r[256] = "";
    uint16_t vid = 0, pid = 0;
    ftdi_host_last_usb_id(&vid, &pid);
    const bool is_vx = (vid == 0x0483 && pid == 0x5740);
    s_uds_only = false;

    /* Reuse the last successful protocol before doing a cold scan.  This is a
       hint only: if the vehicle changed or the protocol no longer answers,
       normal discovery continues immediately. */
    if (try_cached_protocol(is_vx)) return true;

    /* First let the adapter do what ELM applications normally do: automatic
       protocol search.  This is especially important on OBDX Pro because the
       device firmware knows which of its supported CAN/VPW modes to try. */
    ESP_LOGI(TAG, "OBD auto protocol search (ATSP0), adapter=%s", is_vx ? "OBDX VX" : "OBDLink/other");
    if (elm_cmd("ATSP0", r, sizeof(r), 2000)) {
        ESP_LOGI(TAG, "ATSP0 -> %.120s", r);
        if (test_protocol()) {
            char dp[160] = "AUTO";
            if (elm_cmd("ATDP", r, sizeof(r), 1500)) {
                snprintf(dp, sizeof(dp), "AUTO %.120s", r);
                for (char *c = dp; *c; ++c) if (*c == '\r' || *c == '\n' || *c == '>') *c = ' ';
            }
            set_protocol_name(dp);
            char dpn[64] = "";
            uint8_t pn = 0;
            if (elm_cmd("ATDPN", dpn, sizeof(dpn), 1200)) pn = parse_atdpn_protocol(dpn);
            if (pn) save_vehicle_profile(pn, NULL);
            ESP_LOGI(TAG, "Automatic protocol connected: %s (ATDPN=%.20s)", dp, dpn);
            sd_logger_event("OBD", "automatic protocol connected: %s", dp);
            return true;
        }
        ESP_LOGW(TAG, "ATSP0 completed but PID 0100 received no valid response");
    } else {
        ESP_LOGW(TAG, "ATSP0 timed out / transport did not return prompt");
    }

    /* OBDX Pro VX supports J1850-VPW plus 11/29-bit CAN at 250/500 kbit/s.
       Do not waste reconnect time trying PWM/ISO/KWP modes that VX hardware
       does not support.  OBDLink EX keeps the broader legacy fallback list. */
    typedef struct { const char *at; const char *name; const char *header; } proto_try_t;
    static const proto_try_t vx_tries[] = {
        /* OBDX developer docs require an explicit VPW header before sending
           raw Mode-01 payload bytes.  6C 10 F1 = functional PCM request. */
        {"ATSP2", "J1850 VPW", "ATSH6C10F1"},
        /* Explicit functional OBD-II request identifiers for CAN. */
        {"ATSP6", "CAN 11/500", "ATSH7DF"},
        {"ATSP7", "CAN 29/500", "ATSH18DB33F1"},
        {"ATSP8", "CAN 11/250", "ATSH7DF"},
        {"ATSP9", "CAN 29/250", "ATSH18DB33F1"},
    };
    static const proto_try_t ex_tries[] = {
        {"ATSP2", "J1850 VPW", NULL}, {"ATSP6", "CAN 11/500", NULL},
        {"ATSP7", "CAN 29/500", NULL}, {"ATSP8", "CAN 11/250", NULL},
        {"ATSP9", "CAN 29/250", NULL}, {"ATSP1", "J1850 PWM", NULL},
        {"ATSP3", "ISO 9141-2", NULL}, {"ATSP4", "KWP FAST", NULL}, {"ATSP5", "KWP SLOW", NULL},
    };

    const proto_try_t *tries = is_vx ? vx_tries : ex_tries;
    const size_t count = is_vx ? (sizeof(vx_tries) / sizeof(vx_tries[0]))
                               : (sizeof(ex_tries) / sizeof(ex_tries[0]));

    for (size_t i = 0; i < count; i++) {
        /* OBDX VX can switch directly between its supported ELM protocol
           presets.  Keep ATPC for OBDLink legacy behavior only. */
        if (!is_vx) (void)elm_cmd("ATPC", r, sizeof(r), 1200);
        if (!elm_cmd(tries[i].at, r, sizeof(r), 2000)) {
            ESP_LOGW(TAG, "%s (%s) -> timeout", tries[i].at, tries[i].name);
            continue;
        }
        ESP_LOGI(TAG, "%s (%s) -> %.100s", tries[i].at, tries[i].name, r);
        if (strstr(r, "?") || strstr(r, "ERROR")) continue;

        if (tries[i].header) {
            if (!elm_cmd(tries[i].header, r, sizeof(r), 1500)) {
                ESP_LOGW(TAG, "%s header %s -> timeout", tries[i].name, tries[i].header);
                continue;
            }
            ESP_LOGI(TAG, "%s header %s -> %.100s", tries[i].name, tries[i].header, r);
            if (strstr(r, "?") || strstr(r, "ERROR")) continue;
        }

        if (test_protocol()) {
            set_protocol_name(tries[i].name);
            uint8_t pn = (uint8_t)(tries[i].at[4] - '0');
            save_vehicle_profile(pn, NULL);
            ESP_LOGI(TAG, "Protocol selected: %s", tries[i].name);
            sd_logger_event("OBD", "protocol selected: %s", tries[i].name);
            return true;
        }

        /* Newer vehicles can expose generic diagnostics via UDS/J1979-2
           instead of classic Mode 01.  A safe read-only VIN DID probe tells us
           the bus is alive without pretending legacy PIDs are valid. */
        uint8_t pn = (uint8_t)(tries[i].at[4] - '0');
        if (pn >= 6 && pn <= 9) {
            char vin[18] = "";
            if (probe_uds_vin_on_current_can(vin, sizeof(vin))) {
                s_uds_only = true;
                save_vehicle_profile(pn, vin[0] ? vin : NULL);
                xSemaphoreTake(s_lock, portMAX_DELAY);
                s_d.uds_detected = true;
                if (vin[0]) snprintf(s_d.vin, sizeof(s_d.vin), "%s", vin);
                s_d.seq++;
                xSemaphoreGive(s_lock);
                char pname[24]; snprintf(pname, sizeof(pname), "UDS %s", tries[i].name);
                set_protocol_name(pname);
                sd_logger_event("OBD", "UDS/J1979-2-aware vehicle detected on %s VIN=%s", tries[i].name, vin[0] ? vin : "unknown");
                return true;
            }
        }
        ESP_LOGW(TAG, "%s selected but PID 0100 returned no valid OBD response", tries[i].name);
    }
    return false;
}

static void elm_init(void)
{
    char r[256];
    /* Keep initialization to the core ELM commands supported by both OBDLink
       and OBDX Pro.  ATAT0 was removed because disabling adaptive timing is
       unnecessary here and can make slow VPW discovery less tolerant. */
    const char *init[]={"ATZ","ATE0","ATL0","ATS0","ATH0"};
    for(size_t i=0;i<sizeof(init)/sizeof(init[0]);i++) {
        uint32_t timeout = (i == 0) ? 5000 : 2500;
        if(elm_cmd(init[i],r,sizeof(r),timeout)) ESP_LOGI(TAG,"%s -> %.100s",init[i],r);
        else ESP_LOGW(TAG,"%s -> timeout/no prompt", init[i]);
        vTaskDelay(pdMS_TO_TICKS(i == 0 ? 150 : 50));
    }
}


static void discover_and_cache_standard_vin(void)
{
    char r[768] = "";
    char vin[18] = "";
    if (!elm_cmd("0902", r, sizeof(r), 2500)) return;
    if (strstr(r, "NO DATA") || strstr(r, "UNABLE") || strstr(r, "ERROR")) return;
    if (!extract_vin_ascii(r, vin)) return;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    snprintf(s_d.vin, sizeof(s_d.vin), "%s", vin);
    s_d.seq++;
    xSemaphoreGive(s_lock);
    save_vehicle_profile(0, vin);
    ESP_LOGI(TAG, "Vehicle VIN=%s", vin);
    sd_logger_event("VEHICLE", "VIN=%s cached_protocol=%u", vin, (unsigned)s_cached_proto);
}

/* GM P01/P59 enhanced transmission data used by 4L60-E/4L65-E.
   221951 = manual valve / shifter range. Known GM values:
     0x48=P, 0x18=R, 0x50=N, 0x30=D4, 0x78=D3, 0x28=D2.
   22199A = PCM commanded/current forward gear (1..4).
   These are deliberately kept separate: 1951 tells us whether a forward
   gear display is appropriate, while 199A supplies the 1/2/3/4 value. */
static bool s_gm_range_known = false;
static bool s_gm_forward_range = false;
static uint8_t s_gm_range_raw = 0;

static int decode_22199a(const char *r)
{
    uint8_t b[128]; int n=hexbytes(r,b,sizeof(b));
    for(int i=0;i+3<n;i++) if(b[i]==0x62&&b[i+1]==0x19&&b[i+2]==0x9A) {
        uint8_t g=b[i+3]; if(g>=1&&g<=4) return g;
    }
    return 0;
}

static int decode_221951(const char *r, uint8_t *raw)
{
    uint8_t b[128]; int n=hexbytes(r,b,sizeof(b));
    for(int i=0;i+3<n;i++) if(b[i]==0x62&&b[i+1]==0x19&&b[i+2]==0x51) {
        uint8_t v=b[i+3];
        if(raw) *raw=v;
        switch(v) {
            case 0x48: return 1; /* Park */
            case 0x18: return 2; /* Reverse */
            case 0x50: return 3; /* Neutral */
            case 0x30: return 4; /* Drive / D4 */
            case 0x78: return 5; /* D3 */
            case 0x28: return 6; /* D2 */
            default: return 0;
        }
    }
    return 0;
}

static void query_gm_shifter_range(void)
{
    char r[512];
    if(!elm_cmd("221951",r,sizeof(r),900)) return;
    uint8_t raw=0; int range=decode_221951(r,&raw);
    if(range==0) return;
    s_gm_range_known=true;
    s_gm_range_raw=raw;
    s_gm_forward_range=(range>=4 && range<=6);
    xSemaphoreTake(s_lock,portMAX_DELAY);
    s_d.shifter_range_valid=true;
    s_d.shifter_range=(range>=4)?4:range; /* D3/D2 still illuminate D; actual 1-4 is separate. */
    s_d.seq++;
    xSemaphoreGive(s_lock);
    ESP_LOGI(TAG,"GM RANGE 221951 raw=0x%02X forward=%d",raw,(int)s_gm_forward_range);
}

static void query_gear(void)
{
    char r[512]; if(!elm_cmd("22199A",r,sizeof(r),900)) return;
    int g=decode_22199a(r);
    xSemaphoreTake(s_lock,portMAX_DELAY);
    /* If 221951 is available, never show a forward gear while in P/R/N.
       If range PID is unavailable, preserve the old moving-vehicle fallback. */
    bool show = g>0 && (s_gm_range_known ? s_gm_forward_range : (s_d.mph>0.5f));
    s_d.gear_valid = show;
    s_d.gear = show?g:0;
    s_d.seq++;
    xSemaphoreGive(s_lock);
    ESP_LOGI(TAG,"GEAR 22199A raw=%.120s decoded=%d range=0x%02X",r,g,s_gm_range_raw);
}

static bool wideband_pid_supported(void)
{
    for (uint8_t pid = 0x24; pid <= 0x2B; ++pid) if (pid_is_supported(pid)) return true;
    for (uint8_t pid = 0x34; pid <= 0x3B; ++pid) if (pid_is_supported(pid)) return true;
    return false;
}

static void query_first_wideband_afr(void)
{
    static const uint8_t candidates[] = {
        0x24,0x25,0x26,0x27,0x28,0x29,0x2A,0x2B,
        0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B
    };
    uint8_t p[4]; char cmd[8];
    for (size_t i = 0; i < sizeof(candidates); ++i) {
        uint8_t pid = candidates[i];
        if (!pid_is_supported(pid)) continue;
        snprintf(cmd, sizeof(cmd), "01%02X", pid);
        if (qpid(cmd, pid, p, 4, 800)) {
            uint16_t raw = ((uint16_t)p[0] << 8) | p[1];
            float eq = raw / 32768.0f;
            if (eq > 0.05f && eq < 2.5f) {
                xSemaphoreTake(s_lock, portMAX_DELAY);
                s_d.actual_afr = eq * 14.7f;
                xSemaphoreGive(s_lock);
            }
            return;
        }
    }
}

static void dtc_code_string(uint16_t v, char out[8])
{
    const char sys[] = {'P','C','B','U'};
    snprintf(out, 8, "%c%1X%03X", sys[(v >> 14) & 3], (v >> 12) & 3, v & 0x0FFF);
}

static bool list_has_code(const char *list, const char *code)
{
    return list && code && strstr(list, code) != NULL;
}

/* Decode every response line instead of stopping after the first ECU.  This is
   important on CAN vehicles where PCM/TCM/other emissions ECUs can all answer
   the same functional request. */
static int count_code_tokens(const char *list)
{
    if (!list || !*list) return 0;
    int n = 1;
    for (const char *p = list; *p; ++p) if (*p == ' ') n++;
    return n;
}

static bool current_protocol_is_can(void)
{
    if (s_cached_proto >= 6 && s_cached_proto <= 9) return true;
    char proto[24];
    xSemaphoreTake(s_lock, portMAX_DELAY);
    snprintf(proto, sizeof(proto), "%s", s_d.protocol);
    xSemaphoreGive(s_lock);
    return strstr(proto, "CAN") != NULL || strstr(proto, "P6") != NULL ||
           strstr(proto, "P7") != NULL || strstr(proto, "P8") != NULL ||
           strstr(proto, "P9") != NULL;
}

/* Decode all ECU response lines.  ISO 15765/CAN adds a DTC-count byte after
   the positive response SID (43/47/4A).  Legacy protocols do not.  Treat the
   count as advisory and only consume it when it is structurally plausible;
   this also handles ELM-compatible adapters that omit it. */
static int decode_mode_dtc_lines(const char *resp, uint8_t response_sid,
                                 char *out, size_t out_sz)
{
    if (!resp || !out || out_sz == 0) return 0;
    const bool can = current_protocol_is_can();
    const char *cur = resp;
    while (*cur) {
        const char *eol = strpbrk(cur, "\r\n");
        size_t len = eol ? (size_t)(eol - cur) : strlen(cur);
        char line[256];
        if (len >= sizeof(line)) len = sizeof(line) - 1;
        memcpy(line, cur, len); line[len] = 0;
        uint8_t b[96]; int n = hexbytes(line, b, sizeof(b));
        for (int i = 0; i < n; ++i) {
            if (b[i] != response_sid) continue;
            int payload_start = i + 1;
            int payload_end = n;
            for (int k = payload_start; k < n; ++k) {
                if (b[k] == 0x43 || b[k] == 0x47 || b[k] == 0x4A) {
                    payload_end = k;
                    break;
                }
            }
            if (payload_start >= payload_end) continue;

            int j = payload_start;
            int pairs_limit = -1;
            if (can) {
                unsigned advertised = b[payload_start];
                int bytes_after_count = payload_end - (payload_start + 1);
                if (advertised <= 32u && bytes_after_count >= (int)(advertised * 2u)) {
                    j = payload_start + 1;
                    pairs_limit = (int)advertised;
                }
            }

            int parsed_pairs = 0;
            for (; j + 1 < payload_end; j += 2) {
                if (pairs_limit >= 0 && parsed_pairs >= pairs_limit) break;
                uint16_t v = ((uint16_t)b[j] << 8) | b[j + 1];
                if (v == 0) break; /* CAN/ELM frame padding */
                char code[8]; dtc_code_string(v, code);
                if (!list_has_code(out, code)) {
                    size_t used = strlen(out);
                    if (used && used + 1 < out_sz) strncat(out, " ", out_sz - used - 1);
                    used = strlen(out);
                    if (used + strlen(code) < out_sz) strncat(out, code, out_sz - used - 1);
                }
                parsed_pairs++;
            }
        }
        if (!eol) break;
        cur = eol + 1;
        while (*cur == '\r' || *cur == '\n') cur++;
    }
    /* Return the total unique codes currently in the destination.  This is
       important when a Ford HS-CAN retry repeats a code already found by the
       first functional request; returning only newly-added codes hid it. */
    return count_code_tokens(out);
}

static int read_dtc_mode(const char *cmd, uint8_t response_sid,
                         const char *label, char *dest, size_t dest_sz)
{
    char r[1024] = "";
    if (!elm_cmd(cmd, r, sizeof(r), 3500)) {
        ESP_LOGW(TAG, "%s DTC request %s -> timeout/no prompt", label, cmd);
        return 0;
    }
    ESP_LOGI(TAG, "%s DTC %s -> %.300s", label, cmd, r);
    sd_logger_event("DTC_RAW", "%s cmd=%s raw=%.220s", label, cmd, r);
    if (strstr(r, "NO DATA") || strstr(r, "UNABLE") || strstr(r, "BUS ERROR")) return 0;
    return decode_mode_dtc_lines(r, response_sid, dest, dest_sz);
}

static void refresh_dtcs(void)
{
    uint8_t p[2];
    bool mil_known = false;
    bool mil_on = false;
    int reported_count = 0;
    if (qpid("0101", 0x01, p, 2, 1800)) {
        mil_known = true;
        mil_on = (p[0] & 0x80) != 0;
        reported_count = p[0] & 0x7F;
    }

    char stored[128] = "", pending[128] = "", permanent[128] = "";
    int ns = read_dtc_mode("03", 0x43, "STORED", stored, sizeof(stored));
    int np = read_dtc_mode("07", 0x47, "PENDING", pending, sizeof(pending));
    int nx = read_dtc_mode("0A", 0x4A, "PERMANENT", permanent, sizeof(permanent));

    /* Ford powertrain/emissions DTCs on this generation are on HS-CAN.
       Do not make the HS-CAN retry depend on PID 0101 succeeding: if 0101 is
       unavailable/ambiguous, that was previously enough to skip the Ford
       retry completely.  When the Ford profile is selected and the generic
       Mode 03 scan is empty, explicitly force ISO15765 11-bit/500 (7DF). */
    bool ford_hscan_needed = (s_oem_profile == OBD_OEM_FORD && ns == 0) ||
                             (mil_known && mil_on && ns == 0);
    if (ford_hscan_needed) {
        char r[256] = "";
        ESP_LOGW(TAG, "No stored DTC decoded; forcing Ford/HS-CAN 11/500 functional header 7DF (MIL known=%d on=%d profile=%s)",
                 mil_known ? 1 : 0, mil_on ? 1 : 0, oem_name(s_oem_profile));
        if (elm_cmd("ATSP6", r, sizeof(r), 1500) &&
            elm_cmd("ATSH7DF", r, sizeof(r), 1200)) {
            ns = read_dtc_mode("03", 0x43, "FORD HS-CAN STORED", stored, sizeof(stored));
            np = read_dtc_mode("07", 0x47, "FORD HS-CAN PENDING", pending, sizeof(pending));
            nx = read_dtc_mode("0A", 0x4A, "FORD HS-CAN PERMANENT", permanent, sizeof(permanent));
        }
    }

    char codes[320] = "";
    snprintf(codes, sizeof(codes), "STORED: %s\nPENDING: %s\nPERMANENT: %s",
             stored[0] ? stored : "NONE",
             pending[0] ? pending : "NONE",
             permanent[0] ? permanent : "NONE");

    int decoded_total = ns + np + nx;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    s_d.mil_on = mil_known ? mil_on : s_d.mil_on;
    /* Page 3 should reflect every code we actually decoded.  PID 0101 only
       reports the current emissions DTC count and can legitimately be zero
       while Mode 07 pending codes are present.  The old logic therefore hid
       valid pending/permanent codes behind DTC COUNT: 0. */
    s_d.dtc_count = decoded_total > 0 ? decoded_total : (mil_known ? reported_count : 0);
    snprintf(s_d.dtc_codes, sizeof(s_d.dtc_codes), "%s", codes);
    s_d.seq++;
    xSemaphoreGive(s_lock);

    sd_logger_event("DTC", "MIL=%d reported=%d stored=%d pending=%d permanent=%d %s",
                    mil_on ? 1 : 0, reported_count, ns, np, nx, codes);
    if ((s_oem_profile == OBD_OEM_FORD || mil_on) && ns == 0 && np == 0 && nx == 0) {
        sd_logger_event("DTC", "No generic DTC decoded after HS-CAN retry; inspect DTC_RAW lines before treating as truly empty");
    }
}

static void set_dtc_message(const char *msg)
{
    if (!s_lock) return;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    snprintf(s_d.dtc_codes, sizeof(s_d.dtc_codes), "%s", msg ? msg : "");
    s_d.seq++;
    xSemaphoreGive(s_lock);
}

static void clear_dtcs_verified(void)
{
    obd_data_t snap;
    obd_auto_snapshot(&snap);

    /* Clearing emissions DTCs can reset readiness monitors/freeze-frame data.
       Refuse while the engine is running; ignition should remain ON. */
    if (snap.rpm > 100) {
        ESP_LOGW(TAG, "RESET CODES refused: engine running at %d RPM", snap.rpm);
        sd_logger_event("DTC", "reset refused: engine running rpm=%d", snap.rpm);
        set_dtc_message("RESET BLOCKED: STOP ENGINE\nLeave ignition ON, then press RESET CODES again");
        return;
    }

    char r[256] = "";
    bool sent = elm_cmd("04", r, sizeof(r), 3000);
    ESP_LOGI(TAG, "RESET/CLEAR DTC Mode 04 -> %.180s", sent ? r : "TIMEOUT");
    sd_logger_event("DTC", "Mode 04 reset response=%.120s", sent ? r : "TIMEOUT");

    bool bad = !sent || strstr(r, "UNABLE") || strstr(r, "BUS ERROR") || strstr(r, "NO DATA") || strstr(r, "ERROR");

    /* On Ford powertrain, explicitly retry over HS-CAN if the current path did
       not acknowledge the clear.  This is the same 7DF functional path used
       by the Ford read-code fallback. */
    if (bad && s_oem_profile == OBD_OEM_FORD) {
        char t[128] = "";
        ESP_LOGW(TAG, "Mode 04 not acknowledged; retrying Ford HS-CAN 11/500 header 7DF");
        if (elm_cmd("ATSP6", t, sizeof(t), 1500) &&
            elm_cmd("ATSH7DF", t, sizeof(t), 1200)) {
            memset(r, 0, sizeof(r));
            sent = elm_cmd("04", r, sizeof(r), 3000);
            bad = !sent || strstr(r, "UNABLE") || strstr(r, "BUS ERROR") || strstr(r, "NO DATA") || strstr(r, "ERROR");
            ESP_LOGI(TAG, "FORD HS-CAN RESET/CLEAR DTC Mode 04 -> %.180s", sent ? r : "TIMEOUT");
            sd_logger_event("DTC", "Ford HS-CAN Mode 04 reset response=%.120s", sent ? r : "TIMEOUT");
        }
    }

    if (bad) {
        set_dtc_message("RESET FAILED / NO ECU ACK\nRead codes and check connection/protocol");
        return;
    }

    set_dtc_message("RESET SENT - VERIFYING...");
    vTaskDelay(pdMS_TO_TICKS(900));
    refresh_dtcs();
}

static void obd_task(void *arg)
{
    (void)arg;
    int phase=0, slow=0;
    int64_t last_log_us = 0;
    while(1) {
        if(!ftdi_host_ready()) { set_state("USB_OFFLINE"); vTaskDelay(pdMS_TO_TICKS(250)); continue; }
        set_state("ADAPTER_READY"); elm_init(); detect_adapter();
        {
            char vr[64] = "";
            if (elm_cmd("ATRV", vr, sizeof(vr), 1200))
                ESP_LOGI(TAG, "Vehicle connector voltage -> %.40s", vr);
        }
        if(!select_protocol()) {
            set_state("NO_ECU_RESPONSE");
            ESP_LOGW(TAG, "Adapter is alive but no ECU answered any supported VX protocol. Check ignition/key state and vehicle protocol support.");
            vTaskDelay(pdMS_TO_TICKS(3000));
            continue;
        }
        if (s_uds_only) {
            set_state("UDS_READY");
            set_dtc_message("UDS/OBDonUDS VEHICLE DETECTED\nRead-only UDS VIN discovery active\nClassic Mode 03/04 codes are not sent on this path");
            ESP_LOGI(TAG, "UDS-aware vehicle detected; preserving adapter connection without legacy Mode-01 polling");
            while (ftdi_host_ready() && s_uds_only) {
                if (s_oem_scan) {
                    s_oem_scan=false;
                    set_oem_result("UDS VEHICLE", "Legacy OEM ELM probe skipped to preserve the UDS session; platform-specific UDS definitions are required.");
                }
                if (s_refresh_dtcs) {
                    s_refresh_dtcs=false;
                    set_dtc_message("UDS/OBDonUDS VEHICLE\nClassic DTC scan skipped\nOEM/UDS DTC definition required for this platform");
                }
                if (s_clear_dtcs) {
                    s_clear_dtcs=false;
                    set_dtc_message("UDS RESET BLOCKED\nNo generic all-module clear is sent without a verified OBDonUDS DTC profile");
                }
                vTaskDelay(pdMS_TO_TICKS(250));
            }
            continue;
        }

        set_state("LIVE");
        discover_supported_pids();
        discover_and_cache_standard_vin();
        refresh_dtcs();
        uint32_t gear_poll = 0;
        uint32_t range_poll = 0;
        while(ftdi_host_ready()) {
            uint8_t p[4];
            /* RPM is intentionally the high-priority lane for cluster-like response. */
            if(pid_is_supported(0x0C) && qpid("010C",0x0C,p,2,650)) { int rpm=((p[0]<<8)|p[1])/4; xSemaphoreTake(s_lock,portMAX_DELAY); s_d.rpm=rpm; s_d.seq++; xSemaphoreGive(s_lock); }
            switch(phase++%50) {
                case 0: if(pid_is_supported(0x0D)&&qpid("010D",0x0D,p,1,650)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.mph=p[0]*0.621371f;xSemaphoreGive(s_lock);} break;
                case 1: if(pid_is_supported(0x11)&&qpid("0111",0x11,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.tps=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 2: if(pid_is_supported(0x04)&&qpid("0104",0x04,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.load=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 3: if(pid_is_supported(0x0B)&&qpid("010B",0x0B,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.map_kpa=p[0];xSemaphoreGive(s_lock);} break;
                case 4: if(pid_is_supported(0x10)&&qpid("0110",0x10,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.maf_gps=((p[0]<<8)|p[1])/100.0f;xSemaphoreGive(s_lock);} break;
                case 5: if(pid_is_supported(0x05)&&qpid("0105",0x05,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.ect_f=(p[0]-40)*9.0f/5.0f+32;xSemaphoreGive(s_lock);} break;
                case 6: if(pid_is_supported(0x0F)&&qpid("010F",0x0F,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.iat_f=(p[0]-40)*9.0f/5.0f+32;xSemaphoreGive(s_lock);} break;
                case 7: if(pid_is_supported(0x0E)&&qpid("010E",0x0E,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.timing_deg=p[0]/2.0f-64.0f;xSemaphoreGive(s_lock);} break;
                case 8: if(pid_is_supported(0x06)&&qpid("0106",0x06,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.stft1=(p[0]/1.28f)-100.0f;xSemaphoreGive(s_lock);} break;
                case 9: if(pid_is_supported(0x07)&&qpid("0107",0x07,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.ltft1=(p[0]/1.28f)-100.0f;xSemaphoreGive(s_lock);} break;
                case 10: if(pid_is_supported(0x08)&&qpid("0108",0x08,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.stft2=(p[0]/1.28f)-100.0f;xSemaphoreGive(s_lock);} break;
                case 11: if(pid_is_supported(0x09)&&qpid("0109",0x09,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.ltft2=(p[0]/1.28f)-100.0f;xSemaphoreGive(s_lock);} break;
                case 12: if(pid_is_supported(0x2F)&&qpid("012F",0x2F,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.fuel_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 13: if(pid_is_supported(0x1F)&&qpid("011F",0x1F,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.runtime_s=(p[0]<<8)|p[1];xSemaphoreGive(s_lock);} break;
                case 14: if(pid_is_supported(0x0A)&&qpid("010A",0x0A,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.fuel_pressure_kpa=p[0]*3.0f;xSemaphoreGive(s_lock);} break;
                case 15: if(pid_is_supported(0x21)&&qpid("0121",0x21,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.distance_mil_km=(p[0]<<8)|p[1];xSemaphoreGive(s_lock);} break;
                case 16: if(pid_is_supported(0x2C)&&qpid("012C",0x2C,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.egr_cmd_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 17: if(pid_is_supported(0x2D)&&qpid("012D",0x2D,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.egr_error_pct=(p[0]/1.28f)-100.0f;xSemaphoreGive(s_lock);} break;
                case 18: if(pid_is_supported(0x2E)&&qpid("012E",0x2E,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.evap_purge_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 19: if(pid_is_supported(0x30)&&qpid("0130",0x30,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.warmups_since_clear=p[0];xSemaphoreGive(s_lock);} break;
                case 20: if(pid_is_supported(0x31)&&qpid("0131",0x31,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.distance_clear_km=(p[0]<<8)|p[1];xSemaphoreGive(s_lock);} break;
                case 21: if(pid_is_supported(0x33)&&qpid("0133",0x33,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.baro_kpa=p[0];xSemaphoreGive(s_lock);} break;
                case 22: if(pid_is_supported(0x42)&&qpid("0142",0x42,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.control_module_v=((p[0]<<8)|p[1])/1000.0f;xSemaphoreGive(s_lock);} break;
                case 23: if(pid_is_supported(0x45)&&qpid("0145",0x45,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.relative_tps=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 24: if(pid_is_supported(0x46)&&qpid("0146",0x46,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.ambient_f=(p[0]-40)*9.0f/5.0f+32.0f;xSemaphoreGive(s_lock);} break;
                case 25: if(pid_is_supported(0x4C)&&qpid("014C",0x4C,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.cmd_throttle_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 26: if(pid_is_supported(0x43)&&qpid("0143",0x43,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.abs_load_pct=v*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 27: if(pid_is_supported(0x47)&&qpid("0147",0x47,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.throttle_b_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 28: if(pid_is_supported(0x48)&&qpid("0148",0x48,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.throttle_c_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 29: if(pid_is_supported(0x49)&&qpid("0149",0x49,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.pedal_d_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 30: if(pid_is_supported(0x4A)&&qpid("014A",0x4A,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.pedal_e_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 31: if(pid_is_supported(0x4B)&&qpid("014B",0x4B,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.pedal_f_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 32: if(pid_is_supported(0x5A)&&qpid("015A",0x5A,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.rel_accel_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 33: if(pid_is_supported(0x5C)&&qpid("015C",0x5C,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.oil_temp_f=(p[0]-40)*9.0f/5.0f+32.0f;xSemaphoreGive(s_lock);} break;
                case 34: if(pid_is_supported(0x5D)&&qpid("015D",0x5D,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.injection_timing_deg=v/128.0f-210.0f;xSemaphoreGive(s_lock);} break;
                case 35: if(pid_is_supported(0x5E)&&qpid("015E",0x5E,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.fuel_rate_lph=v*0.05f;xSemaphoreGive(s_lock);} break;
                case 36: if(pid_is_supported(0x61)&&qpid("0161",0x61,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.demanded_torque_pct=(float)p[0]-125.0f;xSemaphoreGive(s_lock);} break;
                case 37: if(pid_is_supported(0x62)&&qpid("0162",0x62,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.actual_torque_pct=(float)p[0]-125.0f;xSemaphoreGive(s_lock);} break;
                case 38: if(pid_is_supported(0x63)&&qpid("0163",0x63,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.reference_torque_nm=(p[0]<<8)|p[1];xSemaphoreGive(s_lock);} break;
                case 39: if(pid_is_supported(0x01)&&qpid("0101",0x01,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.mil_on=(p[0]&0x80)!=0;xSemaphoreGive(s_lock);} break;
                case 40: if(pid_is_supported(0x23)&&qpid("0123",0x23,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.fuel_rail_kpa=v*10.0f;xSemaphoreGive(s_lock);} break;
                case 41: if(pid_is_supported(0x3C)&&qpid("013C",0x3C,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.catalyst_b1s1_f=(v*0.1f-40.0f)*9.0f/5.0f+32.0f;xSemaphoreGive(s_lock);} break;
                case 42: if(pid_is_supported(0x3D)&&qpid("013D",0x3D,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.catalyst_b2s1_f=(v*0.1f-40.0f)*9.0f/5.0f+32.0f;xSemaphoreGive(s_lock);} break;
                case 43: if(pid_is_supported(0x3E)&&qpid("013E",0x3E,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.catalyst_b1s2_f=(v*0.1f-40.0f)*9.0f/5.0f+32.0f;xSemaphoreGive(s_lock);} break;
                case 44: if(pid_is_supported(0x3F)&&qpid("013F",0x3F,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.catalyst_b2s2_f=(v*0.1f-40.0f)*9.0f/5.0f+32.0f;xSemaphoreGive(s_lock);} break;
                case 45: if(pid_is_supported(0x4D)&&qpid("014D",0x4D,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.mil_time_min=(p[0]<<8)|p[1];xSemaphoreGive(s_lock);} break;
                case 46: if(pid_is_supported(0x4E)&&qpid("014E",0x4E,p,2,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.clear_time_min=(p[0]<<8)|p[1];xSemaphoreGive(s_lock);} break;
                case 47: if(pid_is_supported(0x59)&&qpid("0159",0x59,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.fuel_rail_abs_kpa=v*10.0f;xSemaphoreGive(s_lock);} break;
                case 48: if(pid_is_supported(0x5B)&&qpid("015B",0x5B,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.hybrid_battery_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);} break;
                case 49: if(pid_is_supported(0x54)&&qpid("0154",0x54,p,2,700)){uint16_t v=(p[0]<<8)|p[1];xSemaphoreTake(s_lock,portMAX_DELAY);s_d.evap_vapor_pa=(float)((int)v-32767);xSemaphoreGive(s_lock);} break;
            }
            if((slow++%25)==0) {
                char r[128]; if(elm_cmd("ATRV",r,sizeof(r),700)){ float v=strtof(r,NULL); if(v>5&&v<20){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.volts=v;xSemaphoreGive(s_lock);} }
                if(pid_is_supported(0x44)&&qpid("0144",0x44,p,2,700)){ uint16_t v=(p[0]<<8)|p[1]; xSemaphoreTake(s_lock,portMAX_DELAY); s_d.afr=(2.0f/65536.0f*v)*14.7f; xSemaphoreGive(s_lock); }
                if(pid_is_supported(0x52)&&qpid("0152",0x52,p,1,700)){xSemaphoreTake(s_lock,portMAX_DELAY);s_d.ethanol_pct=p[0]*100.0f/255.0f;xSemaphoreGive(s_lock);}
                if(wideband_pid_supported()) query_first_wideband_afr();
            }
            /* Gear is driver-facing data, so poll it much faster than the slow
               housekeeping lane. Range is slow because the lever rarely moves. */
            if((gear_poll++ % 4U)==0U) query_gear();
            if((range_poll++ % 20U)==0U) query_gm_shifter_range();
            xSemaphoreTake(s_lock, portMAX_DELAY); s_d.seq++; xSemaphoreGive(s_lock);
            if(s_oem_scan) { s_oem_scan=false; run_oem_readonly_scan(); }
            if(s_refresh_dtcs) { s_refresh_dtcs=false; refresh_dtcs(); s_diag_busy=false; }
            if(s_clear_dtcs) { s_clear_dtcs=false; clear_dtcs_verified(); s_diag_busy=false; }
            int64_t now_us = esp_timer_get_time();
            if (now_us - last_log_us >= 5000000LL) {
                obd_data_t snap;
                obd_auto_snapshot(&snap);
                sd_logger_snapshot(&snap);
                last_log_us = now_us;
            }
            vTaskDelay(pdMS_TO_TICKS(12));
        }
    }
}

esp_err_t obd_auto_start(void)
{
    s_lock=xSemaphoreCreateMutex(); s_resp_sem=xSemaphoreCreateBinary();
    if(!s_lock||!s_resp_sem) return ESP_ERR_NO_MEM;
    snprintf(s_d.state,sizeof(s_d.state),"USB_OFFLINE"); snprintf(s_d.protocol,sizeof(s_d.protocol),"-"); snprintf(s_d.vin,sizeof(s_d.vin),"-"); s_d.uds_detected=false; snprintf(s_d.dtc_codes,sizeof(s_d.dtc_codes),"-"); snprintf(s_d.adapter_name,sizeof(s_d.adapter_name),"USB adapter pending"); snprintf(s_d.oem_profile,sizeof(s_d.oem_profile),"NONE"); snprintf(s_d.oem_status,sizeof(s_d.oem_status),"IDLE"); snprintf(s_d.oem_result,sizeof(s_d.oem_result),"Select an OEM profile");
    load_vehicle_profile_cache();
    ESP_RETURN_ON_ERROR(ftdi_host_start(rx_bytes,NULL),TAG,"ftdi start");
    if(xTaskCreatePinnedToCore(obd_task,"obd_auto",24576,NULL,12,NULL,1) != pdPASS) return ESP_ERR_NO_MEM;
    return ESP_OK;
}
void obd_auto_snapshot(obd_data_t *out){ if(!out||!s_lock)return; xSemaphoreTake(s_lock,portMAX_DELAY);*out=s_d;xSemaphoreGive(s_lock); }
void obd_auto_request_dtc_refresh(void)
{
    if (s_diag_busy || s_oem_scan || s_refresh_dtcs || s_clear_dtcs) return;
    s_diag_busy = true;
    s_refresh_dtcs = true;
}
void obd_auto_request_clear_dtcs(void)
{
    if (s_diag_busy || s_oem_scan || s_refresh_dtcs || s_clear_dtcs) return;
    s_diag_busy = true;
    s_clear_dtcs = true;
}
void obd_auto_set_oil_pressure(float psi,bool valid){if(!s_lock)return;xSemaphoreTake(s_lock,portMAX_DELAY);s_d.oil_pressure_psi=psi;s_d.oil_pressure_valid=valid;s_d.seq++;xSemaphoreGive(s_lock);}

void obd_auto_set_oem_profile(obd_oem_profile_t profile)
{
    s_oem_profile = profile;
    if (!s_lock) return;
    xSemaphoreTake(s_lock, portMAX_DELAY);
    snprintf(s_d.oem_profile, sizeof(s_d.oem_profile), "%s", oem_name(profile));
    snprintf(s_d.oem_status, sizeof(s_d.oem_status), "READY - READ ONLY");
    snprintf(s_d.oem_result, sizeof(s_d.oem_result), "Press READ-ONLY SCAN");
    s_d.seq++;
    xSemaphoreGive(s_lock);
    sd_logger_event("OEM", "profile selected=%s", oem_name(profile));
}

void obd_auto_request_oem_scan(void)
{
    if (s_diag_busy || s_oem_scan || s_refresh_dtcs || s_clear_dtcs) {
        sd_logger_event("OEM", "scan request ignored: diagnostic busy");
        return;
    }
    /* Claim diagnostic ownership immediately, not later in obd_task.  This
       closes the small window where Page 3 and Page 5 could both queue work. */
    s_diag_busy = true;
    s_oem_scan = true;
}
