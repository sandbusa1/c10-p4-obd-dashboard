OBD2 V3K - EX / OBDX PRO VX AUTO-SELECT BUILD

- OBDLink EX remains the fully working USB transport (FTDI 0403:6015).
- Every newly attached USB device now logs VID/PID before filtering.
- ATI/STI adapter identity auto-selects EX vs OBDX Pro/VX whenever the serial transport is available.
- OBDX Pro VX profile advertises Standard OBD-II + USB + J1850-VPW + DVI capability.
- Ford MS-CAN stays enabled only for EX-class hardware.
- SW-CAN stays disabled unless a future adapter transport explicitly supports it.
- Unknown USB serial devices are logged instead of silently ignored.

IMPORTANT: the current direct USB transport is still the proven EX FTDI driver.
If the VX does not enumerate as the same transport, the monitor and SD log will show its VID/PID.
Those IDs are the information needed to add the VX USB class/endpoint driver safely.
