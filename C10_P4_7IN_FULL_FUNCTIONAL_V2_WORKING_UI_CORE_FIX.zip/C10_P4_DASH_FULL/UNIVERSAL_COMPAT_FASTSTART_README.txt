MAIN / NON-FLASHING BUILD
Universal-compatibility and fast-start layer

Preserved working adapter paths
- OBDLink EX: existing USB/FTDI transport unchanged.
- OBDX Pro VX: existing USB CDC-ACM transport unchanged (0483:5740).
- Existing touch XY mapping, GM headers, Ford HS-CAN DTC retry, READ/RESET CODES,
  SD logging, Page 5 OEM profiles and dashboard polling remain.

New connection behavior
1. Load last successful ELM protocol number from ESP-IDF NVS.
2. Try that protocol first for fast reconnect.
3. If it does not answer PID 0100, automatically fall back to ATSP0 and the
   existing adapter-aware protocol sweep.
4. Store the newly successful protocol (ATDPN/manual protocol) for next boot.
5. Read standard VIN with Mode 09 PID 02 when available and cache/display it.

UDS / newer-vehicle awareness
- On CAN modes where classic PID 0100 does not answer, the firmware performs a
  read-only UDS VIN DID probe (22 F1 90).
- A positive 62 F1 90 response marks the vehicle UDS-aware and displays UDS_READY.
- It does NOT send classic Mode 01 polling into a detected UDS-only session.
- It does NOT send an unverified generic UDS all-module clear command. DTC read/
  reset remains fully enabled on the existing classic OBD-II path.

Why the UDS path is conservative
SAE J1979-2 OBDonUDS is based on UDS diagnostic services and is not simply a
renaming of classic Mode 01/03/04 requests. Full generic OBDonUDS PID/DTC support
requires the applicable J1979-2/J1979DA definitions and transport coverage.

Hardware limits remain hardware limits
- OBDX Pro VX: HS-CAN and J1850-VPW only in this build.
- OBDLink EX: legislated OBD-II protocols plus Ford MS-CAN.
- GM SW-CAN, CAN-FD and DoIP require hardware/transport support not present in
  the currently used VX/EX paths.

Build target
- ESP32-P4
- ESP-IDF 5.5.5
- Waveshare ESP32-P4-WIFI6-Touch-LCD-7B
